---
name: dossier
description: >
  Build a paid PDF decision-manual for one destination+audience project (e.g. "Rome, Solved."
  for romeforamericans) from that site's article corpus. It sells the CONNECTIONS the free
  corpus doesn't make: non-obvious, high-stakes synthesis a reader pays for because the facts
  are scattered across dozens of free articles and joined in none (read references/model.md
  FIRST). A two-document deliverable: the BOOK (stable ~2yr analysis) + the FIELD SHEET
  (dated volatile figures, quarterly). Covers the model and synthesis-viability check, corpus
  mining, the decision framework and its quality bar, provenance marks, essays, vector maps
  from real coordinates, the cover, the image brief, the render, flow layout, and the gates.
  Triggers: build the dossier / guide / paid PDF for [project], write decisions, draw the
  maps, dossier image brief, render the dossier, dossier audit. Read state.json FIRST.
---

# Dossier — the paid PDF for one project

One project (destination + audience) → one sellable PDF, built **from that site's own
corpus**. Not a guidebook: a **decision manual**. The reader is anxious six weeks before
a trip, and the product resolves decisions with visible arithmetic.

> **READ `references/model.md` FIRST — before Stage 0.** It is the one idea the whole
> skill serves: you are selling the CONNECTIONS the free corpus doesn't make, not the
> facts. Every decision must be non-obvious to a diligent amateur AND high-stakes. The
> first cold build passed every structural gate and was forgettable because it skipped
> this. A clean book that no one would pay for is the failure this skill exists to prevent.

> Forged on Rome, Solved. — 57pp, 14k words, 21 figures, 13 decisions. Every rule here
> was paid for by a real bug in that build. Do not re-learn them.

```
STAGE 0  INPUTS    corpus export + project name + brand tokens (see references/0-inputs.md)
STAGE A  MINE      corpus → what can this support? + SYNTHESIS CHECK: are the key
                   facts scattered (sellable) or pre-connected (weak)? audit-synthesis.py
STAGE A2 SHAPE     the organising fact + the shape (city? country? region?) — Rome's
                   walk-time thesis does NOT transfer. references/a2-shape.md
STAGE B  DECIDE    the decisions, the provenance marks, the two-document split
STAGE C  WRITE     essays + decisions + failure modes + Field Sheet. OBEY THE
                   PAGE SPECIMEN (references/page-spec.md — exact zones + CSS) and
                   FOLLOW
                   references/writing-code.md: marks are seasoning (1/paragraph,
                   never mid-sentence), and the page has a fixed anatomy.
STAGE D  DRAW      vector figures from REAL coordinates (never stock, never platform tiles)
STAGE E  IMAGE     emit the brief IN THE CHAT (A01, A02…) → user hands back files → wire in
STAGE F  RENDER    Paged.js pagination (scripts/render-paged.py) → PDF, then the gates
STAGE G  AUDIT     audit-furniture.py (the sheet contract, every page) then
                   audit-book.py → clean or clumsy. Quality bar (model.md) is taught,
                   not gated. Design authority: references/layout-architect.md.
```

**Read `references/` only for the stage you're in.** Each one is short and has the code.

---

## The non-negotiables

**1. The corpus is the only source.** Every claim traces to an article the site published,
or it does not ship. No invented facts, no half-remembered prices, no "typically around €X".

**2. Every claim carries a provenance mark.**

| mark | means | lives |
|---|---|---|
| `● ESTABLISHED` | structural, true for years | the Book |
| `◇ OFFICIAL` | regulated fare, published rule, gov advisory | the Book |
| `▲ SURVEYED mm/yy` | our own dated observation | the Book, dated |
| `◆ VOLATILE` | price, hours, release window | **the Field Sheet only** |

**Lint rule: no mark = opinion = cut.** This is the product's moat, not decoration.

**3. The two-document split by shelf-life.** The Book ages slowly and never carries a live
price. The Field Sheet is dated, quarterly, emailed. When they disagree, the Sheet wins.
**Never promise a page count you don't ship** — describe the Sheet by what it *carries*.

**4. What the dossier refuses to do**, and says so on its own back-matter page: name hotels
(we haven't slept in them), name restaurants (wrong by spring — the *rule* outlives the list),
print current prices (they belong on the Sheet), republish anyone's ratings (legally and
editorially radioactive). That page IS the brand. Never let a reviewer talk you out of it.

**5. Photographs are the user's to choose — and every one is LANDSCAPE.** Never generate
them, never pull from an API, never ship a placeholder in a paid product. A 2:3 phone shot
needs 7in of height to fill the column and renders as a stamp; `validate-images.py` gates
this before the build, and the build itself refuses portraits. Aim for **one plate per six
pages, spread across both halves** — `audit-rhythm.py` fails a text-only run over 6 pages. After the text and figures are done, emit the
image brief **in the chat**, alphanumerically (A01, A02…), and stop. The user downloads in
that order and hands the files back. See `references/e-image.md`.

**6. Legal.** No platform API data (Booking/TripAdvisor/Google all prohibit resale in a PDF).
No per-hotel scores. No logos. No negative claims about named businesses. Own artwork only.
Coordinates and geography are public facts — drawing your own map from them is fine.

---

## Quick reference — what goes where

| you're doing | read |
|---|---|
| **starting fresh — what do I need?** | **`references/0-inputs.md`** |
| corpus check, is this destination viable | `references/a-mine.md` |
| **what shape is this destination — city? country?** | **`references/a2-shape.md`** |
| choosing the decisions, writing them | `references/b-decide.md` |
| essays, failure modes, the Field Sheet | `references/c-write.md` |
| maps, illustrations, the cover device | `references/d-draw.md` |
| the image brief + wiring photos in | `references/e-image.md` |
| emit the brief | `scripts/emit-image-brief.py <slots.json>` |
| **validate the photos the user sent** | **`scripts/validate-images.py img/ [--fix]`** |
| **check the book's visual rhythm** | **`scripts/audit-rhythm.py dossier3.html`** |
| **check the pages hold a shape** | **`scripts/audit-page-shape.py dossier3.html`** |
| **design the cover (D.5)** | **`references/cover.md` — argue the thesis, don't template** |
| **lay out the pages (F.5)** | **`references/layout.md` — FLOW chapters, don't hand-place** |
| **THE final gate — clean or clumsy?** | **`scripts/audit-book.py <build-dir>` — runs everything (incl. depth), one verdict** |
| **is the book deep enough?** | **`scripts/audit-depth.py <build-dir>` — yield model, enforced** |
| **THE MODEL — why anyone buys it** | **`references/model.md` — READ FIRST; pay for the connections** |
| **THE LAYOUT ARCHITECT — the design authority** | **`references/layout-architect.md` — the page as a designer sees it: sheet contract, baseline & scale, composition judgment, feathering. Read before Stage C and Stage F.** |
| **THE PAGE SPECIMEN — exact geometry** | **`references/page-spec.md` + assets/page-specimen.png — head/body/foot zones in px, the paged page model** |
| **every sheet furnished & painted?** | **`scripts/audit-furniture.py <pdf>` — the gate that catches the continuation-page bug** |
| **HOW prose sits on the page** | **`references/writing-code.md` — mark density, page anatomy, header hierarchy** |
| **do furniture & body collide?** | **`scripts/audit-geometry.py <pdf>` — dead-zone check (in audit-book)** |
| **prose not over-marked?** | **`scripts/audit-marks.py <pdf>` — confetti check (folded into audit-book)** |
| **is there synthesis to sell? (Stage A)** | **`scripts/audit-synthesis.py corpus.json "theme" ...` — scattered vs pre-joined** |
| build + render + the gates | `references/f-render.md` |
| the refinement loops before ship | `references/g-audit.md` |
| the design system (structure, scale) | `assets/design-system.md` |
| where a project's colours come from | `references/brand-tokens.md` |

---

## The build, in one screen

```
build/
  content.py     decisions (the analytical heart)
  content2.py    terrain, neighborhoods, days, failure modes
  content3.py    the destination's set pieces, day trips, eating, money
  content4.py    pre-departure, PHOTOS dict
  content5.py    first day, rhythm, churches, wallet, calendar
  prose.py       OPENING + the essays (drop caps, standfirsts, pull quotes)
  design2.py     THE CSS LIVES HERE — not in build3.py (see the bug log)
  maps.py        every vector figure, drawn from real lat/lon
  illus.py       drawn illustrations (scope its palette — see bug log)
  covers.py      the cover device
  build3.py      execs the above → dossier3.html
  img/           user-supplied photos, resized
```

Render: `python3 render-paged.py` (copy from `scripts/`, with `assets/paged.polyfill.js`)
— Paged.js paginates the flow into real page divs, the feathering pass finishes the
chapter tails, then Playwright prints. Fonts and photos by FILE URL, never base64.

---

## THE BUG LOG — every one of these actually happened

Read this before touching the build. Each cost real time on Rome.

**1. The CSS lives in `design2.py`.** Edits to `build3.py`'s style block do nothing. Symptom:
"my fix didn't apply." Half the Rome cover bugs were this.

**2. `python3 build3.py` printing "pages: 57" does NOT mean it wrote the file.** A rename left
it writing to `guide3.html` while renders read `dossier3.html` — two hours of "verified" work
went to a file nobody rendered. **Always check the output file's mtime after a build.**

**3. Never `2>/dev/null` the build.** It hides `NameError` and you render stale HTML.

**4. String-replace edits fail silently.** `s.replace(old,new)` with a non-matching `old`
returns the string unchanged and reports success. **Always `assert old in s`** before replacing,
or patch by line index.

**5. A rule you "tuned" may not exist.** `.map.band svg{height:...}` was edited three times
across two sessions; it was never in the stylesheet. Map SVGs sized purely by viewBox aspect.
**`grep` for the selector before tuning it.**

**6. `.map figcaption` fell back to browser default 16px** — *larger than 13.4px body text* —
because a FIG-numbering edit replaced the combined `.map figcaption,.photo figcaption` rule
with `.photo` alone. Symptom: captions look wrong on some pages, fine on others.

**7. `.map` had no margin rule at all**, so map captions welded to the paragraph below them
(0px) while photo captions got 22px. Same symptom: "some pages are OK, some aren't."

**8. Figure too small = the artwork's viewBox, not the CSS.** Rome's day-trip maps were
660×120 and rendered 119px against a reference figure's 293px. Fix the viewBox.

**9. Rebuilding a function by index slice deletes its neighbours.** Rebuilding `MAP_HOOD`
silently removed four `GFX_*` functions and `DAYTRIP_GEO`. **After any slice-rebuild, assert
every public function still loads.**

**10. `illus.py` redefining `C={...}` clobbers `maps.py`'s palette** → `KeyError: 'water'`.
Extend, don't replace.

**11. A collision detector that flags a label beside its own dot reports 36 phantom hits.**
Real collision = the dot's centre falls *inside* the glyph box. Write the strict version first.

**12. A blanket fix breaks what was already right.** "All inside-ring labels point inward"
flipped four correct labels to fix one. **Target the actual condition**, not the category.

**13. External design values don't transfer.** A reviewer's 23px pull quote (designed against
a one-sentence sample) rendered 209px tall against a 90-word verdict and blew the page. Their
A4 canvas and 0.38in margins were wrong for US Letter. **Measure their render, take the ideas,
re-derive the numbers against real content.**

**14. A CSS box that doesn't match the image's aspect silently eats the photograph.**
A 3:1 box with `object-fit:cover` showed 50% of every landscape and **22% of every
portrait** — 78% thrown away, invisibly. The box must follow the image, never the reverse.
`validate-images.py` gates the shape before the build.

**15. `display:flex` on a `<figure>` makes the caption a row sibling of the image.**
Rome v2 shipped captions stranded to the *right* of the picture in dead space. The
`figcaption` CSS was correct the whole time; flex overrode where it landed.

**16. `:has()` does not land in this headless Chromium.** Two separate attempts to style
a page by its contents silently did nothing. Set the class in the generator instead.

**17. Slot IDs and plate letters diverge, silently.** The brief says `A07`; the book prints
`PL. E`, because plates are lettered in page order. Three rounds were lost swapping the wrong
photographs. Letter plates by slot (`chr(64+int(slot[1:]))`), and make the user name their
files `A07.jpg` — not `E.jpg`.

**18. An upload can arrive as a 2-byte file.** GitHub happily served `A08.png` as a bare
`\r\n`. Check the byte count before `Image.open()` and say so plainly — don't diagnose it as
a format problem.

**19. "Stale" means half-empty pages — and it took two wrong diagnoses to find that.**
Greece read as basic. First guess: thin pages. Wrong — its prose is *denser* than Rome's
(1.2% vs 0.9% ink). Second guess: pages packed to the trim edge. Also wrong, and wrong
because **the instrument was broken**: scanning a rendered PDF for its lowest ink finds the
FOLIO and reports ~96% for every book. The truth, measured on the DOM with furniture
excluded: **Greece median fill 60%, 25/41 pages under 65%, range 18-92%. Rome: 71%, 5/49,
range 57-90.** Greece's pages are two-thirds empty and no two are the same shape. Measure
the DOM, not the render.

**20. A plate at the top of a page outranks the figure that carries the argument.** Greece
opened p6 on a photograph and buried its route graph beneath — the reader meets the
decoration before the argument. The *arguing* figure leads; a photo is not automatically it.

**21. A decision is an argument, not a page.** Giving each decision its own two `page()`
calls made every one 55-60% full — six blank pages, and it read as a thin book. FLOW the
chapter (one `.flow` div, break rules, visuals inside the prose) and the engine fills the
pages: Greece 41pp→34pp, median fill 60%→84%, same words. The page count was layout, never
corpus. See references/layout.md.

**22. A figure belongs UNDER the prose that introduces it, not on its own page.** Greece's
route graph sat alone above an unrelated photo while the essay that argued it was 59% full
one page back. Emit the visual inside the flow after its paragraph; it drops onto the same
page when it fits and pushes over only when it must. Never a `page(fig(...))` by itself.

**23. The cover is the highest-leverage page and the first one skimped.** Greece shipped a
1.4%-ink title-on-paper. A cover must ARGUE the thesis (references/cover.md), be computed
from real coordinates so it's unclonable, and get its own render pass — the standalone SVG
hid hard-teal streamlines, a serif-fallback font, and a missing full-bleed. Budget two
rounds, not zero.

**24. Don't hand-maintain a SPLIT set.** Tuning which decisions break where is a loop that
never converges — every fix moves the overflow. Flow the chapter, set the fragmentation
rules once, render, measure. If you're keeping a list of page breaks, you've reverted to
fixed pages.

**25. A clean book can still be a thin book — and the org gate can't tell.** A cold rebuild
of Greece passed audit-book.py green at 19pp: well-filled, paced, good cover. It had used 9%
of an 80-article corpus that supports ~40pp. Organization checks are blind to thinness. The
depth gate (audit-depth.py, now in audit-book.py) catches it: pp/article, words/article, and
% of corpus used, calibrated so the thin build fails and the two good builds pass. Discovered
by the first true cold build — the exact failure a cold test exists to surface.

**26. Always ship corpus.json in the build tarball.** The depth gate needs it; without it,
audit-book.py silently skips depth and a thin book passes. The cold build happened to include
it, which is the only reason we caught this.

**27. Every chapter starts a fresh page; never let a chapter tail orphan into the next.**
Flowed chapters need `break-before:page` on `.chap` (Rome shipped tables splitting mid-row
across pages because only `.page` had the break, not `.chap`). See layout.md.

**28. A figure must render exactly once — guard the emit.** Rome drew FIG.3/5/9/10 twice
because a figure was claimed by both a chapter `fig` key and a decision/plate/renderer. Track
emitted keys, skip repeats, and number by appearance order (a static map + chapter-order
placement gives out-of-sequence captions). layout.md has the guard.

**29. Chapter-break slack is where plates go.** Breaking each chapter to a fresh page leaves
half-empty tails; fill the emptiest ones with a plate rather than stacking images elsewhere,
and pull a figure back onto the previous page when it would otherwise open a new one.

**30. White furniture bands: Chromium CLIPS template backgrounds** (full-bleed div,
oversized paint, background attr — all clipped) and bare `@page` margins are unpainted.
Watch for a hidden `@page{margin:1.02in}` in the CSS — that was Rome's real white band.
The per-chapter in-body runhead this entry once recommended is ITSELF bug #33 — the whole
mechanism class is superseded by the paged page model (page-spec.md).

**31. A chapter ending >70% empty wants another plate.** The corpus supports one more figure
or photo; two-thirds of a blank page is the signal to add it. layout.md — but fix the double
margin first, since most "empty" space is really wasted margin.

**32. Verify by extracting, not by looking.** Pulling the PDF's text is what caught
"COLOSSEUM" clipped to "COL" and two labels rendering outside the canvas entirely.

**33. Per-chapter furniture margins chapter-START pages only.** The in-body runhead fix
(old #30) gave a correct 92px top + furniture on the first page of each chapter, and
continuation pages started 2-3px from the trim, unfurnished, edge to edge. Chromium also
does not repeat `position:fixed` across printed pages. Margins and furniture must be a
property of the PAGE — the paged page model (Paged.js slices the flow into real page divs;
page-spec.md) is the only mechanism in this Chromium that furnishes and paints every page.
`audit-furniture.py` exists to catch this class: it fails the old architecture on nearly
every page and must pass on every build.

**34. Base64 megabytes silently truncate the paginated book.** With data-URI fonts the
CSS parse stalls for minutes; with data-URI photos the paginator's measure loop STOPS THE
BOOK EARLY with no error — Rome came out 37 of 48 pages, at a different point each run.
Fonts and photos are referenced by file URL, and the renderer pre-decodes images before
pagination. A short book after a render = check this first.

**35. Two selectors setting one named string shadow each other.** `string-set: rh` on
both `.dnum` and `.rh-src` made continuation runheads show a STALE chapter (the paginator
keys captured strings per selector). One selector per string — every section emits one
invisible `.rh-src` span after its H1.

**36. Feathering replaced hand-placed tail fixes.** Chapter tails are finished by the
renderer's measured TIGHT/FEED/LOOSE pass (layout-architect.md §4), bounded at ±1 notch,
recomputed every build. Escalate a tighten that fails to clear its tail (a 2-line orphan
is worse than the 6-line one you started with), and never keep a hand list of which pages
get what — that is the split-set antipattern (#24) in new clothes.

**37. The audit instrument must match the architecture.** The stub gate's 40%-of-sheet
line was calibrated on the double-margin flow; under real 92/72px pages the same sheet
fraction holds far more column, and an endmark-closed verdict apparatus at 38% is a set
tail, not dribble. Recalibrated to a third of the sheet — the same instrument correction
as #19: when the layout model changes, re-derive what the gates measure before trusting
either a pass or a fail.
