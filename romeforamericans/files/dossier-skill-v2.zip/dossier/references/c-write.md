# Stage C — The prose

> **Follow `references/writing-code.md` for HOW prose sits on the page** — provenance-mark
> density (one per paragraph, never mid-sentence — the first cold build hit 28 marks on one
> page and became unreadable), the fixed page anatomy, and the header hierarchy. This file is
> the voice and content; that file is the typographic code.

# Stage C (voice) —  Write

## Register

Economist/Monocle, not travel blog. Calm, confident, no fluff, no enthusiasm, no emoji.
The reader is an intelligent adult spending thousands on a trip. **Show the reasoning; let
them disagree.**

The test an outside reviewer applied to Rome and it passed: *"Most Rome guides answer 'where
should I eat?' This answers 'how should I think?'"*

## The chapter set that works

```
OPENING          the contract: "so you can disagree with us and still come out ahead"
HOW TO READ      the marks + the two documents + "using this on the trip"
CONTENTS         a TOC. A $39 product without one is a PDF, not a publication.
THE GROUND       the ORGANISING FACT — the one thing that reorganises the trip.
                 Rome's is scale; a country's is sequencing. See a2-shape.md.
                 + the transit-reality page (why the obvious tool doesn't help)
BEFORE YOU FLY   the checklist, every line with a deadline
DAY ZERO         the arrival day — the most anxious hours, and nobody writes it
TIMING           the rhythm of the week (closures, strikes, the seasonal trap)
THE SET PIECES   the destination's 2-3 unavoidable operations, each with its order-of-ops
EATING           the rule that outlives any list of names
MONEY            where it actually leaks
THE DECISIONS    13 × 1pp — the heart
THE HORIZONS     the booking calendar (stable horizons; prices live on the Sheet)
WHERE TO STAY    6 assessments on identical criteria + a decision tree
THE PLAN         the days, as operations not itineraries
THE FOURTH DAY   day trips, verdict up front
FAILURE MODES    20, organised BY CONSEQUENCE — the thing a website of articles can't do
KIT              the wallet card (print it, carry it)
BACK MATTER      "What this won't tell you" — the brand
CLOSING          about the destination, never about your methodology
FIELD SHEET      the dated annex
```

## Prose craft

- **Drop cap** opens a chapter. Never a verdict, never mid-page.
- **Standfirst** is the argument in one sentence, italic, above a hairline rule.
- **Pull quote** must not repeat body text on the same page (Rome shipped that bug).
- **Three wonder paragraphs, no more.** Rome's: the Pantheon threshold, the first espresso
  standing at the bar, the bridge at dusk. Anticipation is part of what's being sold — but
  four is a travel blog.

## The words that expose the machine

Count them. Rome's first draft: *actually* 20×, *whole* 13×, *structural* 10×, *honest* 10×,
*genuinely* 9×. **"Honest" was the worst** — the book kept *saying* it was honest instead of
being it.

```python
import re
full = ' '.join(p.extract_text() for p in PdfReader(pdf).pages).lower()
for w in ['actually','whole','structural','genuinely','honest','exactly','simply','precisely']:
    print(f"{len(re.findall(r'\\b'+w+r'\\b', full)):3}×  {w}")
```

Target ≤ 5 each in a 14k-word book. Every fix is a **judged rewrite**, not a deletion.

## The Field Sheet

- Only **real verified values** under "Verified at press time · <month>".
- Everything unverified becomes **"Confirm in your travel week ◆ — where to look"** with the
  official source named. Never a blank cell, never "— verify".
- **Never promise a page count.** Rome promised six pages and shipped two — for a product
  whose premise is honesty, that discredits every other claim in the book.
- State the survey method once, plainly, and mark it `▲ SURVEYED`.


## The refusals page — reframed by the model

"What this book won't tell you" is NOT the book's identity — it is a CONSEQUENCE of the
model in `references/model.md`. The book sells reality (the connections, the real model behind the naive one). One
person's dinner recommendation is not reality — it is a data point that rots in a season and
that the reader can get free anywhere. So the refusal is not "we're too pure to name a
restaurant"; it is **"we refuse to fake reality, and a single restaurant pick is fake
certainty."**

Frame every refusal as protecting the buyer from false confidence:
- not "we won't name restaurants" → "a named restaurant is a guess with a byline; what
  outlasts it is the RULE for spotting the right one, which we do give you."
- not "we won't list hotels" → "a hotel pick is stale in a season; the DECISION of which
  area, and why, is what we make — and it doesn't expire."

The refusals page should leave the reader MORE confident they bought the durable thing, not
feeling something was withheld. It is the model stated as a boundary.