# THE MODEL — why anyone buys this, and what makes it great

Read this first. Every other stage serves it. A dossier that ignores this is clean, true,
and forgettable — which is exactly how the first cold build failed: it passed every
structural gate and no one would have paid for it.

## You are selling the connections, not the facts

The facts about any destination are free and infinite. That is the buyer's problem, not
their need. Six weeks before a trip they are drowning in 40 open tabs, and what they will
pay $29-39 for is **relief from the anxiety of deciding** — a competent voice that says
"here is what actually matters, here is the call, you will not screw this up."

The one thing a book can do that the free web cannot is hold the whole corpus in mind at
once and **make the connections no single free article makes.** That is the product.

> Greece example, measured on the real corpus: the central call ("sequence Santorini last
> or gamble your flight home") needs four facts — the meltemi, the ferry types, the fixed
> return flight, the sequencing logic. They appear in 19, 21, 13, and 9 of 80 articles.
> Exactly **2 articles** contain all four. The facts are everywhere; the connection is
> almost nowhere. **That gap is the entire value of the book.**

The reader pays for the synthesis. The free articles supply the pieces — and by being
un-connected, they advertise the paid book that connects them. Your blog is the puzzle;
the dossier is the solved puzzle.

## The quality bar: every decision lands in the bottom-right cell

```
                    OBVIOUS                 NON-OBVIOUS
  LOW-STAKES    | brochure filler         | trivia / "fun fact"
  HIGH-STAKES   | true but no help (anxiety)| ★ THE PRODUCT ★
```

A claim is worth its place only if it is BOTH:

- **NON-OBVIOUS** — to a *diligent amateur*: someone who read the top blogs, the Reddit
  threads, the first two Google pages, and STILL would not know this. Not non-obvious to a
  naif (too easy a bar — everything qualifies) and not to an expert (impossible bar). The
  corpus itself is the amateur baseline: if a single free article already states it flatly,
  it is obvious by construction — the free web has it. The book's job is the synthesis
  *across* articles that no one article makes.
- **HIGH-STAKES** — getting it wrong costs real money, a lost day, or the trip itself. A
  true, non-obvious call that costs nothing to ignore is trivia.

The first cold build lived in the two wrong cells: obvious-and-important (anxiety, no help)
and non-obvious-and-trivial (fun facts). True, clean, deep — and forgettable. Bottom-right
is the only cell worth money.

## The four edges — a WRITING lens, never a required tag

A high-stakes call cuts on at least one edge. Use these to *find* the sharp calls, not to
label them:

- **MONEY** — you paid more than needed (the fast-ferry premium; the DCC "pay in USD?" prompt)
- **EXTRACTION** — someone engineered the gap to profit (tourist-menu markup, the taxi meter)
- **BREAKAGE** — optimism the physics punishes (the ferry cancels, the connection is missed)
- **EXPERIENCE** — the residual that separates a great trip from a fine one (when Oia clears)

Do NOT make these a per-decision tag the audit enforces. MONEY and EXTRACTION overlap
constantly, and EXPERIENCE is a catch-all a lazy build hides in. They are a thinking prompt:
"have I considered all four kinds of harm?" — nothing more.

## The dominant edge — found by tally, not by assumption

Destinations differ in which edge dominates, and **you cannot guess it — the corpus tells
you.** Tally the corpus's own warnings, costs, and mistakes; the heaviest bin is the book's
centre of gravity, and it decides what the cover promise leads with.

> Greece by raw tally: MONEY 828 cues, BREAKAGE 265, EXPERIENCE 247, EXTRACTION 88. I had
> *assumed* Greece was breakage-shaped (the wind, cancellations) — the count said money,
> and corrected me. That is the check doing its job: overturning the builder's own naive
> model of the destination. (Keyword tallies over-count price words; treat the raw number
> as a signal, not gospel — but the SHAPE is informative.)

Rome would tally extraction-heavy (a centre engineered to separate tourists from cash); a
beach destination might tally experience-heavy (low money stakes, all taste-calibration).
The frame ADAPTS to the destination instead of imposing one shape. If the corpus is thin on
cost cues and thick on "which spot is actually worth it," the book is correctly about taste,
not savings — and money does NOT lead the cover.

## The free hook

The book contains a dozen syntheses; **give ONE away** as the sample of judgment that sells
the rest. The sharpest, most "wait — I would NOT have known that" call, stated free. The
buyer cannot see the whole book before paying, but one real connection, free, proves the
judgment is worth buying. Identify it during the build (it is usually the organising fact's
own call) so whatever storefront wraps the PDF has its trailer.

## What is enforced vs taught (be honest about this)

- **Enforced, objective:** ONLY the synthesis viability check at Stage A
  (`audit-synthesis.py` — are the key facts scattered and rarely pre-joined?). This one is a
  pure co-occurrence count with no semantic judgment, so it is honest to gate.
- **Taught, NOT gated** (tested — a gate here would be theatre): whether each decision names
  a stake, whether the free hook is identified, whether a naive model is real or a strawman,
  whether a call is genuinely non-obvious. Stake language turned out to be dense in the prose
  but not anchorable to a countable unit once chapters flow, so a stake-counting gate
  miscounts; and "is this the sharpest call" is a meaning judgment no regex reads. A gate
  that pretends to check these passes strawmen with the right keywords — worse than nothing.
  These live on the writer's honesty. The test to apply yourself to every claim:
  *"would a sharp friend who researched this actually not know it, and does getting it wrong
  cost real money, a day, or the trip?"* If no to either, cut or demote it.

## The through-line, in one sentence

**Pay for the connections.** Non-obvious, high-stakes synthesis the free facts don't
assemble — that is what makes the book worth reading AND worth buying, because they are the
same property. Everything else in this skill (the decisions, the provenance marks, the
reality-vs-brochure voice, money leading the cover) is a corollary of this one idea.
