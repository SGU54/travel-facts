# Stage B — The decisions

The decisions ARE the product — but ONLY if they clear the bar in `references/model.md`.
Read that first if you haven't. A decision earns its place only when it lands in the
bottom-right cell: **NON-OBVIOUS** to a diligent amateur (they read the blogs and Reddit and
still wouldn't know it) **AND HIGH-STAKES** (getting it wrong costs real money, a day, or
the trip). A true, clean, sourced decision that fails either test is what made the first
cold build forgettable. Before writing any decision, apply the test:

- **Is it non-obvious?** If a single free article in the corpus already states it flatly,
  it's obvious — the free web has it. The paid value is the SYNTHESIS across articles that no
  one article makes. Cut or demote the obvious ones.
- **Is it high-stakes?** Name what believing the naive model costs. If the honest answer is
  "not much," it's trivia — cut it.
- **What's the naive model?** The default plan a *sharp* first-timer actually arrives with —
  mined from the corpus's own "many visitors think / common mistake" material, NOT invented.
  A strawman nobody believes is worse than no naive model. If a sharp friend wouldn't
  actually hold the belief, you're strawmanning — fix it.

The single sharpest decision is your **free hook** (model.md) — usually the one that follows
from the organising fact. Identify it; it sells the rest.

## What makes a decision (not a chapter)

A decision is a question the reader is **already Googling**, answered with **visible
arithmetic** and a verdict that **can be disagreed with**. Rome's thirteen:

```
Base      Where should you actually stay?
Arrival   Train, taxi, or transfer from the airport?
Transit   Do you need transit tickets at all?
Tickets   The city pass, or pay as you go?
Booking   What must be booked in advance — and how far?
Money     Cards or cash — and the one question that costs you money?
Time      Three days or four — what does the fourth buy?
Season    When should you go — and what does it cost you?
Eating    How do you avoid eating badly in a city this good at food?
Risk      How worried should you be?
Flights   Nonstop or connection — does the flight decide day one?
Tickets   Arena floor, underground, or the standard ticket?
Evening   Is aperitivo dinner, or a prelude to it?
```

**Decisions do not transfer between destinations.** "Roma Pass or not" has no Lisbon
analogue. Each project needs its own few hours of real analysis — that's the per-site cost
and it's why this is defensible.

## The shape

```python
DECISION = {
 "n":"01", "cat":"Base",
 "q":"Where should you actually stay?",
 "cols":"WALK · PRICE",          # ← ledger column header. NEVER ship an unlabelled column.
 "lede":"...",                    # the reframe: why the obvious answer is wrong
 "table_title":"The trade-off, scored · first-time American, 3 days",
 "rows":[("option — what it is <span class='mk est'>●</span>","the number")],
 "verdict":"<strong>The call.</strong> Then the reasoning, 60-90 words.",
 "for":["then it's yes → ..."],
 "against":["then it's no → ..."],
 "note":"<span class='mk vol'>◆ VOLATILE</span> what to re-check, and where.",
}
```

**Rules:**
- **Every ledger gets a column header.** Rome shipped 13 unlabelled number columns through
  ten refinement loops and a full audit before an outside reviewer caught it.
- **All openings must differ.** Rome had two decisions opening "This is the most/highest…" —
  self-important, and the template shows. Check them as a set, not one at a time.
- **The verdict is a conclusion, not an essay** — no drop cap on it.
- **Cross-reference** — "the arithmetic is on p.17". The manual feel comes from the network.

## Budget a visual while you choose the decisions

**This is where the rhythm defect is born.** Fourteen decisions written back-to-back become
fourteen identically structured pages, and no later loop can fix it — by then every page is
full. Rome v2 shipped a 15-page text-only run straight through its decisions.

As you pick the decisions, mark which ones **carry a visual**:

| the decision turns on… | it wants |
|---|---|
| a place, a distance, a route | a locator or a distance map |
| a number that moves over time | a strip or a grid (the month bars) |
| a fork inside one object | a section drawing (the Colosseum tiers) |
| a habit at a counter or a door | **a plate** — the photo IS the evidence |
| a rule with a threshold | the ledger alone is fine — leave it clean |

**Target: something visual on every third or fourth decision.** Not decoration — a decision
that can't carry a figure honestly is a decision whose ledger is doing the work, and that's
fine. But three in a row with nothing is a wall.

## The best lede is a scene, not a claim

Rome's booking decision went from *"This is the highest-impact page in this book"* to:

> *"Nearly every ruined morning in Rome starts the same way: an American arrives at a major
> sight expecting to buy a ticket at the door."*

## The verdict must be losable

If the verdict can't be argued with, it isn't a decision — it's a fact, and facts belong in
the essays. The opening contract: *"so you can disagree with us and still come out ahead."*
