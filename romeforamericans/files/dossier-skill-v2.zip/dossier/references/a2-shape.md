# Stage A2 — What SHAPE is this destination?

**Run this before choosing a single decision.** The skill was forged on a compact city; if you
apply Rome's shape to a country you will assert things that are false.

## The organising fact

Every dossier turns on **one fact that reorganises the reader's mental model**. Rome's is
*"the historic centre is two miles across"* — it decides the cover, Decision 01, the transit
chapter, and the day plans. **Find the equivalent, or the book has no spine.**

It is *not* always distance.

| shape | example | the organising fact is | the cover device draws |
|---|---|---|---|
| **compact city** | Rome, Florence, Kyoto | *scale* — it's all inside 1km | the ring + real walk-times |
| **sprawl city** | Tokyo, LA, Bangkok | *the transit graph* — which line you sleep on | the line you actually live on |
| **country / archipelago** | Greece, Japan, Croatia | **sequencing** — the ferry/train that only runs Tue & Fri | the route graph with its frequencies |
| **region** | Tuscany, Provence | *the base you pick* — one hub or three | the drive-time isochrone from each candidate base |
| **one-way corridor** | Iceland ring, Route 66 | *direction and fuel* — the leg you can't undo | the loop with its commit points |

## How to find it — from the corpus, not from instinct

```python
# which categories dominate? that IS the shape.
# Rome: neighborhoods + walking + one metro chapter    → compact city
# Greece: islands + ferries + Athens + seasons         → sequencing
```
Then ask of the top categories: **what does a first-timer get catastrophically wrong here?**
- Rome: they overbuy transit and stay outside the walls to save €30.
- Greece: they book islands in the wrong order and lose two days to a ferry that doesn't run.

That mistake is the organising fact. The book exists to prevent it.

## What changes when the shape changes

**Greece is not Rome with different nouns.** A country dossier:
- has **no walk-time thesis** — delete the terrain chapter, don't translate it
- needs a **sequencing chapter** the city book has no equivalent of
- has **ferry/flight frequency** as its ◆ VOLATILE core — the Field Sheet gets bigger, not smaller
- has **season** as a first-order decision, not eighth — half the islands close
- may need **"which islands, and in what order"** as Decision 01, where Rome had "where to sleep"
- its cover device draws **the route graph**, not a ring

**Do not port Rome's 13 decisions.** Mine that destination's own from its own corpus (Stage A).
The decisions are the product; a swapped noun is a fraud.

## The audience is half the shape

`<destination>for<audience>` — both halves matter. The same corpus produces different books:

| | for Americans | for Brits |
|---|---|---|
| flights | nonstop premium from the East Coast | budget carriers, hand-luggage rules |
| money | **DCC** — the dollars-or-euros prompt | no DCC problem; different card fees |
| entry | ETIAS, 90-day Schengen | different post-Brexit rules |
| driving | IDP needed | licence works |
| tipping | must be un-taught | already normal |
| "far" | 2h is nothing | 2h is a journey |

Rome's Decision 06 exists **because Americans reliably answer one card-reader prompt wrong**.
That decision doesn't exist in a British edition. Ask what *this* audience gets wrong.

## Output of this stage — before any writing

```
□ the organising fact, in one sentence
□ the shape (compact city / sprawl / country / region / corridor)
□ what this audience specifically gets wrong
□ the cover device that draws the organising fact
□ which of the standard chapters DON'T apply — and what replaces them
```
