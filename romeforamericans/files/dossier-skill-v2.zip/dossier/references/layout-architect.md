# THE LAYOUT ARCHITECT — the design authority for the book

**Read this before Stage C and again before Stage F.** It is the layer that thinks about
the page the way a book designer does, BEFORE anything renders. The other references carry
rules; this one carries the point of view the rules serve, and it is authoritative over
them: where page-spec.md, layout.md, or design-system.md conflict with this file, this
file wins. It exists because a build once passed every structural gate and still read as
"generated" — inconsistent margins, furniture that appeared on some pages and not others,
pages that were legal and still looked undesigned.

## The point of view

This book is a paid object. The reader's trust in the *argument* is transferred from the
*object*: a page that holds its shape says "someone decided this," and a page that doesn't
says "a machine emitted this," regardless of how good the prose is. So the design has one
governing idea:

> **Every sheet is the same instrument playing different bars.** One grid, one baseline,
> one furniture system, one spacing scale — and inside that constancy, deliberate variety:
> a full-bleed cover, image-dominant closing pages, dense ledger spreads, airy tails.
> Variety on top of constancy reads designed. Variety instead of constancy reads broken.

The test for any page is never "which rule does this violate?" It is: **could you overlay
any two body pages of the book and watch the margins, the runhead, the folio, and the
baseline coincide exactly?** If yes, the book has a page. If no, it has 47 separate
documents.

## 1 · The sheet contract (the page model)

The book is paginated by a real pagination engine (Paged.js) into actual page divs before
printing — see page-spec.md for the mechanism and the graveyard of approaches that don't
work in this Chromium. What matters here is the *contract* every sheet signs:

- **The paper reaches all four trim edges.** No white band of any width, ever. The page
  div itself is the paper, so this holds by construction — but it is gated anyway
  (`audit-furniture.py`), because three previous mechanisms held it "by construction" too
  and shipped white bands.
- **The column is constant**: body lives in 92–984px vertically, 82px side margins, on
  every page — chapter starts and continuations alike. Margins are a property of the
  PAGE, never of the chapter.
- **Furniture is per-page**: running head in the head band, folio in the foot band, on
  every interior page. The running head carries the book title left and the current
  chapter right (set by the chapter, repeated by the page).
- **Named exceptions are named**: the cover (`page: cover`, full bleed, no furniture) and
  the annex (`page: annex`, same bands, its own bottom clearance). An exception the CSS
  can't name is a bug, not a design.

### The opener convention

A chapter-opening page **suppresses its running head** (the folio stays). The opener
announces itself — eyebrow, H1, standfirst; a runhead repeating the same words 40px above
them is the tell of a template, not a book. The renderer enforces this mechanically: any
page whose content carries an H1 is an opener (chapters always break to a fresh page, so
an H1 can only sit at a page top).

## 2 · The grid: one baseline, one scale, one ramp

### Baseline

Body type is **13.4px on a 22.5px line** — and 22.5px is *the* vertical unit of the book.
There is exactly one body leading. (The pre-architect build ran the flow at 1.72 and the
spec at 1.68 — two books interleaved. Reconciling them recovered roughly a line per page.)

### Spacing scale

Every vertical space in the book is one of these steps, chosen from the baseline:

```
  6   ·  hairline gap (caption padding, rule offsets)
 11   ·  half-line    (paragraph after-space, list items)
 17   ·  ¾-line       (figure/table entry, standfirst padding)
 22.5 ·  ONE LINE     (inter-block minimum — below this, blocks weld)
 34   ·  1½ lines     (H2 approach, section-internal breathing)
 45   ·  2 lines      (major transitions inside a page)
 68   ·  3 lines      (only the chapter-open stack uses this much)
```

The rule that matters: **any gap between two blocks ≥ one line (22.5px), and any gap
within a block ≤ ¾-line.** That single asymmetry is what makes a page parse at arm's
length. An ad-hoc value ("26px felt right") is how the previous files accumulated
nineteen different margins; when a space needs tuning, move it to the adjacent step, don't
invent a twentieth value.

### Type ramp

One ramp, ratio ≈ 1.27 between working steps, three faces with fixed jobs:

```
   8   mono      eyebrow, caption, ledger header   (8 is the print floor — never below)
   9   mono      furniture (runhead, folio), marks
  11   mono      H2 — a LABEL, visibly subordinate to H1, never the display face
  12   body      ledger cells, asides
  13.4 body      BODY — the reference note; everything is sized relative to it
  17   display-i standfirst
  19   display   H3
  39/44 display  H1 (chapter question) — one per section
  ~104 display   cover title only
```

The display face carries *statements* (titles, verdict lead-ins), the body face carries
*argument*, the mono face carries *apparatus* (labels, captions, furniture, marks). A
piece of text set in the wrong face is a hierarchy error even at the right size.

## 3 · Composition: where things sit and why

**A chapter opens as a fixed stack**: eyebrow → H1 → standfirst → rule → drop-capped first
paragraph. Openers are the book's most repeated composition; their sameness is the
constancy the rest of the variety stands on. Never improvise an opener.

**A figure sits under the prose that introduces it** — inside the flow, after its
paragraph (chapters default to after paragraph 2; override with `fig_after` when the
introducing paragraph is elsewhere). A figure emitted after ALL the prose is a figure the
engine will maroon on its own page whenever it doesn't fit the tail — which is how a
near-full-page figure strands ten lines of text on a page that's 75% air.

**The arguing figure outranks the photograph.** On any page holding both, the figure that
carries the argument comes first in reading order; the plate paces, it never leads.

**A plate can close a chapter.** A tall (4.35in) full-column photograph, caption, endmark,
air below: that is a designed closing-image page, and it is where a chapter's plate goes
when the tail would otherwise strand a fragment (see feathering, below). A plate alone at
2.55in at the TOP of an otherwise empty page is not this — it is a marooned photo.

**Whitespace is spent, not left over.** The air under a closing plate, the third of a page
below a decision's verdict apparatus, the empty lower half of the annex — each is either
*closed* (by the endmark, the ◆ that tells the reader "this section chose to stop here")
or it is a defect. The endmark is what converts a partial page from absence into air:
every chapter and decision carries one.

**When is a page doing too much?** Two visuals fighting for one page (both shrink); a
ledger, a verdict, AND a figure stacked with under-one-line gaps; an H2 within 3 lines of
the page foot. The fix is a content decision — cut a row, move the plate — never "make it
fit" by shrinking type or gaps below the scale.

**When is a page doing too little?** Body ink ending in the top third with no closural
device; a figure alone with no words; a tail of fewer than ~6 lines. These are what the
feathering pass exists to remove — and any that survive it are the signal to add the
figure or ledger row the corpus already supports (that is a Stage B/C decision, not a
layout patch).

## 4 · Feathering — the compositor's three cards

Real books are finished by a compositor who pulls widows back and feeds thin pages. The
render does the same, **by measurement, every build, never by a hand-kept list** (a
hand-kept list of page fixes is the split-set antipattern — it never converges). After
pagination the renderer measures every chapter's tail fragment and plays, per chapter:

1. **TIGHT** — the tail is smaller than what tightening can recover (≈48px per preceding
   page, +90px per tall plate the chapter holds): set the chapter one notch tighter
   (22px leading, 10px paragraph space, plates to 2.3in) and the tail pulls back onto the
   page entirely. If tightening fails to clear the tail, it is reverted and escalated —
   a 2-line orphan is worse than the 6-line one you started with.
2. **FEED** — the tail is too big to pull back and the chapter holds a plate: the plate
   moves to the chapter's end as a 4.35in **closing plate**. The tail becomes an
   image-dominant closing page instead of a stranded fragment.
3. **LOOSE** — no plate to feed and the tail is under ~42% of the column: the chapter is
   set one notch more open (24px leading) so the tail page receives enough lines to read
   set rather than abandoned.

The bounds are the point: tight and loose are ±1 notch from the baseline, defined here,
applied per chapter — never global, never further. A book whose whole colour changed to
fix one tail has been padded, and audit-page-shape is calibrated to catch exactly that.

Tails the cards can't fix (a complete verdict apparatus landing at ~35–40% of the sheet)
are legitimate chapter tails — closed by the endmark, they read as the book breathing.
The stub gate draws the line at a third of the sheet: below that is a fragment, not a
tail.

## 5 · Before render / after render

**Before writing layout code**, walk this list — it is the difference between designing
and debugging:

- [ ] every vertical value you're about to write is on the spacing scale
- [ ] every font-size is on the ramp, in the face the ramp assigns
- [ ] every figure/plate is emitted INSIDE the prose, after its introducing paragraph
- [ ] every section carries an `id`, an `rh-src`, and an endmark
- [ ] anything special about a page is expressible as a named `@page` — if it isn't,
      redesign it until it is
- [ ] nothing in the body typesets what the furniture owns (chapter name, folio, title)

**After render**, two gates in order:

1. `scripts/audit-furniture.py dossier.pdf` — the sheet contract, checked on EVERY page:
   painted to the trim, furnished, body inside the column. This is the gate that catches
   the continuation-page failure class: mechanisms that furnish chapter starts and strand
   the pages after them.
2. `scripts/audit-book.py <build-dir>` — the composition verdict: fill, consistency,
   stubs, rhythm, marks, cover, geometry, depth.

A build that passes both can still be improved — the gates are the floor. The ceiling is
the overlay test at the top of this file, and the honest read of a spread at arm's
length: does it look like someone chose this? If a page passes every gate and the answer
is still no, the defect is upstream in this file's terms — name which principle it
violates, fix the system, and let the next build inherit the fix.
