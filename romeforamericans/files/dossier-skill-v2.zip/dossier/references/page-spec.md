# THE PAGE SPECIMEN — the exact geometry every page obeys

This is not guidance, it is a SPEC. The specimen (assets/page-specimen.png) shows an empty
page with every zone measured. The previous build collided body text with the footer because
the skill described "don't collide" but never gave the numbers. Here are the numbers. Use
them verbatim.

## The zones (US Letter, 816×1056px @96dpi = 8.5×11in)

```
  ┌─────────────────────────────────────────┐  0px          ← trim edge
  │            HEAD BAND  40–74px            │               running head ONLY
  ├─────────────────────────────────────────┤  92px         ← BODY STARTS
  │                                         │
  │   BODY COLUMN   92 – 984px  (892px)     │   text margin 82px L & R
  │                                         │
  ├─────────────────────────────────────────┤  984px        ← BODY ENDS
  │            FOOT BAND  984–1056px         │               folio ONLY
  └─────────────────────────────────────────┘  1056px       ← trim edge
```

| zone | top → bottom | rule |
|---|---|---|
| **HEAD BAND** | 40 → 74px | running head only — body content is FORBIDDEN here |
| **BODY COLUMN** | 92 → 984px (892px tall) | all prose, figures, tables, verdicts live here |
| **TEXT MARGIN** | 82px left & right (0.854in) | body never crosses these |
| **FOOT BAND** | 984 → 1056px | folio (page no. + short title) only — body FORBIDDEN |

The 18px between the head band (74) and body top (92), and the clearance above the foot band,
are the guarantee that furniture and content never touch.

## The mechanism that produces exactly this (the paged page model)

The zones above are implemented as REAL `@page` margins, made honest by client-side
pagination: **Paged.js** (vendored at `assets/paged.polyfill.js`, injected by
`scripts/render-paged.py`) slices the flow into actual page divs before printing. Each
printed sheet is a DOM element, so the paper paints edge-to-edge by construction, the
margins live INSIDE the painted box, and the running head + folio are margin boxes that
exist on EVERY page — chapter starts and continuations alike.

```css
@page{
  size:8.5in 11in;
  margin:92px 82px 72px 82px;              /* head band / text margin / foot band */
  @top-left{ content:"Rome, Solved." }
  @top-right{ content:string(rh, last) }   /* the current chapter, set by .rh-src */
  @bottom-left{ content:"Rome for Americans" }
  @bottom-center{ content:"\25c6" }
  @bottom-right{ content:counter(page) }
}
@page cover{ margin:0;                      /* full-bleed, unfurnished */
  @top-left{content:none} @top-right{content:none}
  @bottom-left{content:none} @bottom-center{content:none} @bottom-right{content:none} }
@page annex{ margin:92px 82px 76px 82px; }  /* same bands, its own foot clearance */
.coverpage{ page:cover; }  .fs{ page:annex; }

/* the sheet IS the paper */
html,body{ background:var(--paper); -webkit-print-color-adjust:exact; }
.pagedjs_sheet{ background:var(--paper); }

/* ONE selector sets the running-head string — two selectors setting the same
   string shadow each other in the paginator. Every section emits an invisible
   .rh-src span right after its H1. */
.rh-src{ string-set: rh content(text);
  display:block; height:0; overflow:hidden; font-size:0; line-height:0; margin:0; }

/* furniture typography targets the margin-box elements the paginator renders */
.pagedjs_margin-top-left .pagedjs_margin-content,
.pagedjs_margin-top-right .pagedjs_margin-content{
  font-family:var(--mono); font-size:9px; letter-spacing:.14em; color:var(--muted);
  text-transform:uppercase; }
```

Renderer contract (`render-paged.py`): inject the polyfill with `PagedConfig={auto:false}`,
wait for `document.fonts.ready`, pre-decode every image, run `preview()`, wait on its
promise, then `page.pdf(prefer_css_page_size=True, print_background=True, margin=0)` and
**assert the DOM page count equals the PDF page count**. Openers suppress their running
head via a Paged handler (any page whose content holds an H1 is an opener). Bonus the
model buys for free: the TOC's page numbers are REAL — rows link to section ids and
`target-counter(attr(href), page)` resolves the printed folio at layout time; never type
page numbers again.

**Two feeding rules the paginator imposes, both learned the hard way:**
- **No base64 megabytes.** Fonts and photos are referenced by FILE URL, never data-URI.
  Base64 fonts in the stylesheet stall the CSS parse for minutes; base64 photos in the
  DOM make the measure loop stop the book early, SILENTLY (Rome truncated at p37 of 48
  with no error). The renderer pre-decodes the file images before pagination.
- **One selector per named string** (see `.rh-src` above).

## The graveyard — mechanisms that DO NOT work in this Chromium

Tested exhaustively; do not re-try them:

1. **Playwright header/footer templates** — Chromium CLIPS any background you give the
   template (full-bleed div, oversized paint, background attr — all clipped). The
   reserved margin renders WHITE against coloured paper. Hard limitation.
2. **Bare `@page{margin}` without pagination** — the margin band is unpainted (white),
   and margin boxes fail silently. Also watch for a hidden `@page{margin:1.02in}` in the
   CSS overriding your zero — that was one build's white band all along.
3. **`position:fixed` furniture** — printed on page 1 only; Chromium does not repeat it.
4. **Per-chapter in-body furniture** (runhead as the chapter's first child) — furnishes
   and margins chapter-START pages only; every continuation page starts 2-3px from the
   trim, unfurnished. This was the live bug the paged model replaced.

## The type hierarchy (the specimen's proportions)

| element | face | size | rule |
|---|---|---|---|
| part divider / eyebrow | mono | 8px, +.26em, UPPER | one per chapter, above H1 |
| **H1** (chapter question) | display | 34–44px | one per section |
| standfirst | display italic | 15–19px | one line; chapter opens require it |
| body | body serif | 13–14px / 1.68 | justified; drop-cap first para of a chapter only |
| **H2** (sub-section) | **mono or small-caps, ≤12px** | | **MUST read visibly subordinate to H1** |

The previous build set H2 at 25px in the display face — nearly H1's size — so sub-sections
looked like new chapters and the page lost its order. H2 is a mono/small-caps LABEL, not a
smaller headline. The eye must instantly rank H1 > H2.

## What "the body never enters a band" means in practice

- Never type the chapter name, site name, or page number into a paragraph. Those are
  furniture; they render once from the template. ("GREECE, IN ORDER — DOSSIER" colliding with
  the last prose line was body text where furniture belongs.)
- If a figure or table would extend past 984px, it moves to the next page — it does not grow
  into the foot band. (layout.md's break-inside:avoid enforces this.)
- The running head repeats identically on every page of a chapter; it is not a subtitle and
  never varies line to line.

## Gate

`scripts/audit-geometry.py <dossier.pdf>` measures each rendered page for body ink in the
DEAD ZONES — the empty strips between the furniture line and the body (head 76–91px, foot
982–996px). Furniture legitimately sits in the bands; only the dead zones must be clear. A
page with body ink in a dead zone fails, meaning content bled into furniture space.

NOTE: a build made before this spec (body padding < 92px top) will fail even if it looks
clean, because its body starts inside the head dead zone. That is correct — it is not
spec-compliant. Use the verbatim CSS above and the body starts at 92px, clearing the zone.


## Gate, extended

`scripts/audit-furniture.py <dossier.pdf>` checks the sheet contract on EVERY page —
painted to the trim, runhead+folio present, body inside the column — and is specifically
built to catch the continuation-page failure class (chapter starts pass, page 2 of the
chapter fails). Run it before audit-geometry; it fails the old architecture loudly.
