# Stage G — AUDIT: is the book clean, or clumsy?

## Run ONE command. Ship on green.

```bash
python3 scripts/audit-book.py <build-dir>
```

This is the layer that guarantees the PDF is organized and reads evenly — it bundles every
check into a single clean/clumsy verdict so nothing is forgotten. It reads the RENDERED
PDF (once chapters flow, the DOM no longer maps to pages — the print engine makes them, so
only the PDF is ground truth). It checks:

| check | fails when | fix |
|---|---|---|
| page-shape | median fill < 66%, or > 30% of pages half-empty | FLOW the chapters (layout.md) |
| consistency | body fill swings more than 62 points | flow evens it; a slab next to a stub is the tell |
| no orphan stubs | a chapter TAIL dribbles onto a near-empty page | one flow per run of chapters, not a patchwork |
| rhythm | a text-only run longer than 6 pages | budget visuals into the dry stretch (b-decide.md) |
| cover | page 1 < 6% non-paper — a bare title | argue the thesis (cover.md) |
| depth | < 0.40 pp/article, or < 11% of corpus used | mine deeper (a-mine.md), don't pad |

Green = the book is well-filled, evenly shaped, visually paced, fronted by a cover that
argues something, AND deep enough to have used its corpus. That is "clean". Ship it.

The depth row is the one a cold build failed: it is possible to build a perfectly clean
SHORT book that skimmed its corpus. audit-book.py now refuses it. (Depth only runs if
`corpus.json` is in the build dir — always ship the corpus with the build.)

Red = "clumsy", with the specific rows to fix. Do NOT ship a clumsy book by overriding the
gate; fix the cause. Every red row maps to a reference file that says how.

## The one hard case the gate surfaces: the patchwork stub

A book that mixes flowed chapters with fixed pages will strand a chapter's tail on a
near-empty page at the seam (Greece: a 63-word Operations tail on its own page). The gate
flags it as an orphan stub. The real fix is architectural, not a patch: **make the body one
continuous flow** and mark chapter starts with `break-before: page` only where a fresh page
genuinely helps the reader. A patchwork of flow + fixed will always stub at the joins — the
gate is telling you the seams are the problem.

## Reading the individual gates

The bundled gate is the verdict; the individual scripts give detail when a row is red:
`audit-page-shape.py <pdf>` (per-page fill), `audit-rhythm.py <html>` (the visual map as a
P/f/. string). Use them to locate a failure, then fix at the stage the table points to.
