# content.py — THE DECISIONS. Each clears the bottom-right bar (non-obvious + high-stakes),
# each argued with visible arithmetic and a losable verdict. Corpus-sourced, marked.
from prose import mk
EST = mk("est"); OFF = mk("off"); VOL = mk("vol"); SUR = mk("sur")

# Each decision: dnum, rt (right tag), title, standfirst, lede(html), cols, table_title,
# rows[(opt_html, num)], verdict(html), for[], against[], note(html), fig(key or None)

DECISIONS = [
{
 "n":"01","rt":"the free call · p.9","cat":"SEQUENCE",
 "title":"Which islands, in what order — and why the last boat decides",
 "standfirst":"The prettiest islands do not choose your trip. The sequence does — and the leg before your flight is the one that can cost you the trip itself.",
 "lede":f"""<p class="dropcap">A first Greek trip is chosen by order, not by beauty. The naive plan a
 sharp first-timer arrives with is a wish-list — Santorini, Mykonos, maybe one more — assembled by
 appeal and then slotted into the days in whatever sequence the calendar allows. That is exactly
 backwards. The islands are close enough in charm and far enough apart in logistics that the binding
 constraint is the network between them, not the ranking of them.</p>
 <p>The rule that falls out of the wind (see The Ground, p.7) is this: build the sequence so the
 riskiest crossing sits in the <em>middle</em> of the trip, not against your flight home. In practice
 that means moving outward from Athens and ending on Santorini — the farthest island {EST} — reached
 with a day in hand, and flown back from rather than sailed. Two islands is the sweet spot for a week;
 three for ten days, and only if you keep the legs short. {EST}</p>""",
 "cols":"THE LEG · WHAT IT RISKS",
 "table_title":"A week, scored by where the risk sits · Athens + two islands",
 "rows":[
   ("<span class='opt'>Athens → Mykonos → Naxos → <b>Santorini</b> → fly home</span><br><span class='gloss'>risky fast-boat leg falls mid-trip; end island has an airport</span>","low"),
   ("<span class='opt'>Athens → Santorini → Naxos → fly home</span><br><span class='gloss'>Santorini first wastes the finale and still leaves a sea leg late</span>","mid"),
   ("<span class='opt'>Athens → Naxos → Santorini → ferry back on flight day</span><br><span class='gloss'>the exact trap: a wind-cancelled boat takes the flight with it</span>","high"),
   ("<span class='opt'>Five islands in seven days, any order</span><br><span class='gloss'>every move adds a cancellation exposure; the trip becomes transit</span>","highest"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Go outward and end high, with a buffer.</strong>
 Athens first as the opener, then one relaxed island, then Santorini as the finale — reached a day
 before you need to leave it, and flown back to Athens rather than sailed. {EST} You can disagree with
 our island picks and keep the structure; the structure is what protects the flight. The one move we
 will not endorse is a fast-ferry hop scheduled on your departure day. Nothing else in this book carries
 that stake.""",
 "for":["<b>then it holds:</b> you want the famous finale — take it, but take it last and take it early enough to fly out",
        "<b>then relax it:</b> you're travelling in the shoulder season, when the meltemi is not a factor — the order matters less, though the buffer still earns its place"],
 "against":["<b>then rethink:</b> you're set on four or five islands in a week — the sequence can't save a plan that is mostly boats",
            "<b>then rethink:</b> you've booked the island-to-airport ferry for your flight morning — rebook it now, before anything else"],
 "note":f"""<b>{VOL} Confirm in your travel week:</b> the specific sailing days and times for your legs,
 and whether your end island's airport has last-minute Athens flights. Timetables change year to year;
 the Field Sheet names where to check.""",
 "fig":"FIG_ASYMMETRY",
},
{
 "n":"02","rt":"","cat":"FIT",
 "title":"Which islands actually fit you — past the default two",
 "standfirst":"Santorini and Mykonos are the default because they are famous, not because they fit every trip. Matching the island to the traveller is where a good first trip is won.",
 "lede":f"""<p class="dropcap">The default first-timer answer is Santorini for the views and Mykonos for
 the scene, and for many travellers that is genuinely the right pair. {EST} But it is a default, not a
 diagnosis, and it quietly overspends: the two most famous islands cost multiples of the quieter ones
 for a similar week, {EST} and their personalities are specific enough that a mismatch shows up on day
 two. The non-obvious move is to treat the choice as a fit problem — what kind of days you want — rather
 than a fame ranking.</p>
 <p>The corpus's own advice, assembled, is a matching rule the individual island guides never state
 together: pair one <em>showstopper</em> with one <em>relaxed</em> island, and let the relaxed one be
 where you actually unwind. {EST} Naxos and Paros — the two best-value islands in the Cyclades — are the
 ones first-timers skip and repeat visitors love, with bigger beaches, real working villages, and
 noticeably lower prices. {EST} (Their own decision is on p.16.)</p>""",
 "cols":"THE ISLAND · WHAT IT IS FOR",
 "table_title":"The Cyclades shortlist, by what the day feels like",
 "rows":[
   ("<span class='opt'>Santorini</span><br><span class='gloss'>the caldera and the sunset; dramatic, romantic, expensive, busy</span>","finale"),
   ("<span class='opt'>Mykonos</span><br><span class='gloss'>the scene — nightlife, beach clubs, a lively but breathable town</span>","energy"),
   ("<span class='opt'>Naxos</span><br><span class='gloss'>biggest of the group; best beaches, a mountainous interior, great value</span>","base"),
   ("<span class='opt'>Paros</span><br><span class='gloss'>the relaxed, well-connected middle choice; a chic harbour, gentle pace</span>","balance"),
   ("<span class='opt'>Milos / Ios &amp; others</span><br><span class='gloss'>quieter or younger; add once you know which way your taste runs</span>","extend"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Book one famous, one relaxed — and make the relaxed
 one Naxos or Paros.</strong> The famous island earns its place as the finale; the value island earns its
 place as the trip's actual rest. {EST} A pair chosen this way costs less <em>and</em> reads better than
 two headline islands back to back, which double the price and the crowds without doubling the trip.
 Disagree on the specific islands freely — the pairing logic is the durable part.""",
 "for":["<b>then it fits:</b> you want the postcard and you want to relax — one of each is the whole point",
        "<b>then extend:</b> you have ten days — add a third, and make it the one that matches whichever half you preferred"],
 "against":["<b>then reconsider:</b> you're drawn to two headline islands only — you're paying a fame premium twice; at least make one of them the finale",
            "<b>then simplify:</b> it's a five-day trip — resist the pair entirely and do Athens plus one island well (p.14)"],
 "note":f"""<b>{VOL} On the Sheet:</b> current relative pricing shifts with season and exchange rate; the
 <em>ordering</em> (famous islands cost multiples of value islands) is structural and stays here.""",
 "fig":"FIG_DECISIONTREE",
},
{
 "n":"03","rt":"","cat":"BASE",
 "title":"Where to sleep on each island — and why hotel-hopping punishes you",
 "standfirst":"On an island, your base is not a hotel choice — it decides which beaches and sights are even reachable. Moving every night quietly destroys days.",
 "lede":f"""<p class="dropcap">The instinct on a multi-day island is to move around it — a night here, a
 night there, to "see it all." On the small islands that is merely inefficient; on the large ones it is
 self-defeating, and the corpus names the mistake outright: treating a big island like a small one and
 hotel-hopping every night, when the distances punish it. {EST} Your base is the decision; the room is a
 detail underneath it.</p>
 <p>The reason is that a base defines a radius. From a western Crete base, the famous lagoon beaches are
 day trips; from an eastern base they are a wasted driving day. {EST} On Santorini, the caldera towns —
 Oia, Fira, Imerovigli — are the view you came for, but they are a steep, slow climb from the port and
 from each other, so where you sleep sets your whole rhythm. {EST} The move that reads as thrifty —
 chasing a cheaper room one town over — often costs more in transfers and lost time than it saves.</p>""",
 "cols":"THE BASE CHOICE · WHAT IT BUYS",
 "table_title":"Base logic by island type · nights in one place beats a room per night",
 "rows":[
   ("<span class='opt'>Santorini — caldera town vs a sensible room</span><br><span class='gloss'>a night or two on the caldera for the view, the rest somewhere practical</span>","hybrid"),
   ("<span class='opt'>Crete — one region, several nights</span><br><span class='gloss'>Chania (west) or Heraklion (centre); day-trip the rest, don't relocate nightly</span>","one base"),
   ("<span class='opt'>Naxos / Paros — the main town</span><br><span class='gloss'>compact enough that one central base reaches most of the island</span>","central"),
   ("<span class='opt'>Mykonos — town vs the beaches</span><br><span class='gloss'>town for the scene and walkability; a beach for quiet — pick your priority</span>","by taste"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Pick one base per island and stay put; buy the
 view in nights, not in moves.</strong> On Santorini the honest hybrid is a night or two in a caldera-view
 room for the experience and the rest somewhere sensible. {EST} On Crete, one region for several nights
 always beats relocating every night, because there the distance is the constraint, not the opening hours.
 {EST} The room you pick matters far less than the base you pick.""",
 "for":["<b>then split:</b> the caldera view is non-negotiable — take it for a night or two, then move to value, not the reverse",
        "<b>then centralise:</b> it's a compact island — one central base reaches almost everything without a second move"],
 "against":["<b>then reconsider:</b> you've booked a different town each night on a big island — you've booked driving days; consolidate",
            "<b>then note:</b> you want to see both ends of Crete — split a week between two bases deliberately, not four (p.13)"],
 "note":f"""<b>We do not name hotels.</b> A room we praise is stale by spring and one we haven't slept in
 is a guess with a byline. What outlasts the list is the base logic — which town, and why — and that is
 what we give you. See the back matter, p.31.""",
 "fig":None,
},
{
 "n":"04","rt":"","cat":"CRETE",
 "title":"Crete: one region or bust — distance, not hours, is the limit",
 "standfirst":"Crete is not an island you tour; it is a small country. The trip-killer is treating its length as something you can cover, when the limiting factor is the road.",
 "lede":f"""<p class="dropcap">Crete tempts first-timers into a mistake the smaller islands never could:
 the plan to "do Crete" end to end. It is the largest Greek island by far, roughly 160 miles east to
 west, and Chania to Heraklion alone — two of its hubs, not its extremes — is about a two-hour drive.
 {EST} The naive model is that a week is enough to see the island; the real model is that a week is
 enough to see <em>a region</em> of it, well.</p>
 <p>The corpus states the governing constraint plainly, and it is the opposite of what a sights-list
 implies: the limiting factor is always driving distance, not opening hours. {EST} Highlights are
 scattered along a long island, so grouping them by region and giving each base several days beats
 trying to chase all of them. {EST} The figure opposite draws the span to scale — and shows why a
 western base and an eastern base are effectively two different trips.</p>""",
 "cols":"THE PLAN · WHAT IT COSTS IN DAYS",
 "table_title":"Crete by trip length · region depth beats island breadth",
 "rows":[
   ("<span class='opt'>West only (Chania base)</span><br><span class='gloss'>Chania, the lagoon beaches, the gorges — the island's greatest hits</span>","1 base"),
   ("<span class='opt'>Centre (Heraklion base)</span><br><span class='gloss'>Knossos, the museum, central beaches; a different Crete entirely</span>","1 base"),
   ("<span class='opt'>West + centre, split a week</span><br><span class='gloss'>two bases, deliberately — see both ends without nightly moves</span>","2 bases"),
   ("<span class='opt'>All three ends in one week</span><br><span class='gloss'>the trap: most of the week becomes the drive between them</span>","don't"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Pick a region and go deep; add a second base only
 with 7+ days.</strong> For most first-timers the answer is western Crete — Chania, the lagoon beaches,
 and the gorges deliver the island's greatest hits in its most scenic corner. {EST} Ten days or more opens
 all three regions at a relaxed pace; {EST} anything less and the honest choice is one region done well
 over three regions glimpsed from the car. And treat Crete as its own destination, not a Cyclades hop —
 it is too large and too far to fold into an island-hopping week. {EST}""",
 "for":["<b>then west:</b> it's your first time and you want the postcard Crete — Chania and the lagoons are the answer",
        "<b>then two bases:</b> you have a full week or more and want range — split west and centre, and drive once, not nightly"],
 "against":["<b>then rethink:</b> you planned Crete as a two-night stop between Cyclades islands — it doesn't work; give it its own trip",
            "<b>then narrow:</b> you want all three ends in five days — you want a driving holiday; pick one end instead"],
 "note":f"""<b>{VOL} Confirm in your travel week:</b> whether the seasonal boat trips and some beach access
 (Elafonisi, Balos) are running — several are seasonal. The Sheet names the official source.""",
 "fig":"FIG_CRETE",
},
{
 "n":"05","rt":"see The Ground, p.7","cat":"FERRY",
 "title":"Fast boat or conventional — and the one leg where it isn't your choice",
 "standfirst":"For most legs the fast-versus-slow ferry is a comfort-and-time trade you can make on taste. For one leg — the one before your flight — the wind makes it for you.",
 "lede":f"""<p class="dropcap">Two kinds of boat serve most routes, and the difference is usually a
 straightforward trade. High-speed catamarans are quicker and pricier, with airplane-style indoor
 seating and limited deck access; they save time but get bumpy in choppy seas. {EST} Conventional
 ferries are slower, cheaper, steadier, and often more pleasant — you sit on deck with a coffee and the
 crossing is part of the trip. {EST} A fast boat to Santorini might be about five hours where the slow
 one is closer to eight. {EST} For most of your trip, that is simply a preference.</p>
 <p>For one leg it is not. The meltemi cancels the light fast catamarans first while the heavier
 conventional ferries keep sailing in the same conditions. {EST} So on the leg right before your flight
 home — the leg where a cancellation costs the most — the choice is made for you: take the sturdier
 conventional boat, or fly, and keep a buffer either way. {EST} This is the corpus's single most-repeated
 warning, and the one it never fully assembles in one place.</p>""",
 "cols":"THE LEG · THE RIGHT BOAT",
 "table_title":"Which boat, by leg · comfort is taste, the flight leg is not",
 "rows":[
   ("<span class='opt'>A short Cyclades hop, calm seas, time-pressed</span><br><span class='gloss'>fast is great — quicker, and the bump is brief</span>","fast, fine"),
   ("<span class='opt'>Prone to seasickness, or travelling with kids/luggage</span><br><span class='gloss'>conventional, every time — steadier, open deck, easier boarding</span>","conventional"),
   ("<span class='opt'>The leg right before your flight home</span><br><span class='gloss'>conventional plus a buffer — a wind-cancelled fast boat costs the flight</span>","not your choice"),
   ("<span class='opt'>A long haul (Athens–Crete and similar)</span><br><span class='gloss'>consider flying instead — see p.15</span>","fly"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Choose by leg, and hand the flight leg to the
 conventional boat.</strong> Mix freely across the trip — fast when the sea is calm and time is short,
 conventional when comfort or seasickness matters. {EST} But favour the sturdier conventional ferry, with
 a buffer, for any leg before your flight home, when a cancellation would cost you most. {EST} The comfort
 calls are yours; the flight-leg call is the wind's, and arguing with it is the expensive kind of wrong.""",
 "for":["<b>then fast:</b> calm seas, a short hop, a tight schedule mid-trip — the catamaran is the right tool",
        "<b>then conventional:</b> a sensitive stomach, or the leg is your last before flying — steadier wins"],
 "against":["<b>then reconsider:</b> you booked the fast boat off your final island for flight morning — swap it to conventional or a flight, and add the buffer",
            "<b>then note:</b> you assumed the fast boat always runs — in July and August it is the first thing the wind cancels"],
 "note":f"""<b>{VOL} Confirm in your travel week:</b> current fast/slow timetables and which port your ferry
 uses (Piraeus, Rafina, or Lavrio). Book ahead in peak season; schedules thin in shoulder months.""",
 "fig":"FIG_FERRYFLY",
},
{
 "n":"06","rt":"","cat":"FLY",
 "title":"When to fly instead of ferry the long legs",
 "standfirst":"The ferry is the romantic way to island-hop, and for the short Cyclades hops it is the right one. On the long legs, romance costs you most of a day.",
 "lede":f"""<p class="dropcap">Ferries are the way to move between the close Cyclades — frequent, scenic,
 and part of the experience. {EST} But Greece has a well-developed domestic flight network hubbed at
 Athens, and on the longer distances the arithmetic tilts hard toward flying. The naive assumption is
 that ferries are simply how you get around the islands; the sharper view is that the ferry is right for
 short hops and wrong for long ones, and knowing the line saves a day.</p>
 <p>The numbers make the case. Flying Athens to Santorini is about 45 minutes against five to eight hours
 by ferry — most of a day, saved, on a trip where days are the scarce resource. {EST} For a long leg like
 Athens to Crete, a one-hour flight beats a ferry of eight to nine hours or an overnight crossing. {EST}
 Island-to-island flights are a different story: direct hops like Santorini to Mykonos are limited, so the
 ferry (two to three hours) is usually the better choice there. {EST}</p>""",
 "cols":"THE LEG · FERRY vs FLY",
 "table_title":"Where flying buys back a day · door-to-dock, by mode",
 "rows":[
   ("<span class='opt'>Athens ↔ Santorini</span><br><span class='gloss'>~45 min flight vs 5–8 hr ferry — flying saves most of a day</span>","fly"),
   ("<span class='opt'>Athens ↔ Crete (Heraklion / Chania)</span><br><span class='gloss'>~1 hr flight vs 8–9 hr ferry or overnight — fly</span>","fly"),
   ("<span class='opt'>Short Cyclades hop (e.g. Mykonos ↔ Naxos)</span><br><span class='gloss'>frequent, scenic, 1–2 hr — ferry is the point</span>","ferry"),
   ("<span class='opt'>Santorini ↔ Mykonos direct</span><br><span class='gloss'>direct flights limited; the 2–3 hr ferry is usually better</span>","ferry"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Ferry the short hops; fly the long legs and the
 trip's spine.</strong> For the close Cyclades, the ferry is frequent and scenic and part of the trip.
 {EST} For the long distances — Athens to Santorini, Athens to Crete — fly, and buy back most of a day.
 {EST} And flying home from your last island to Athens is not indulgence, it is insurance: it is the leg
 the wind can't cancel. Weigh it per leg, not as a blanket rule.""",
 "for":["<b>then fly:</b> the leg is long (Athens–Santorini, Athens–Crete) and your days are tight — the flight pays for itself in time",
        "<b>then fly for safety:</b> it's the leg off your final island before your international flight — fly it regardless of price"],
 "against":["<b>then ferry:</b> it's a short, frequent Cyclades hop — the boat is cheaper, scenic, and barely slower",
            "<b>then ferry:</b> you wanted to fly Santorini–Mykonos — direct flights are scarce; the ferry is the practical choice"],
 "note":f"""<b>{VOL} On the Sheet:</b> current domestic fares and flight frequencies — both move with season.
 The <em>time</em> comparison here is structural; the price is not, so it lives on the Sheet.""",
 "fig":None,
},
{
 "n":"07","rt":"","cat":"MONEY",
 "title":"The card-reader question — and the American tipping reset",
 "standfirst":"Greece is card-friendly and cheaper than most of Western Europe. The money you lose here is not lost to prices; it is lost to two habits an American brings from home.",
 "lede":f"""<p class="dropcap">Ask what a Greek trip costs and the honest answer is that it varies enormously
 — a budget-friendly European trip or a serious splurge, depending on which islands, when, and how you
 travel. {EST} Which is why the "Greece costs $X a day" figures online mislead more than they help: the
 same day can cost wildly different amounts. {EST} We do not print a fake per-day number. We tell you where
 the money actually leaks — and for an American, it leaks in two specific places that have nothing to do
 with the price of anything.</p>
 <p>The first is the card reader. At an ATM or a payment terminal you will be offered the choice to be
 charged in dollars instead of euros. Take the euros, every time: declining the conversion avoids a bad
 built-in markup. {EST} And avoid the Euronet machines in tourist areas — poor rates and fees — in favour
 of a bank ATM. {EST} The second is the tip. Greek tipping is modest — rounding up or leaving 5–10% at a
 taverna is plenty; there is no American-style 18–20% expectation, and applying one quietly overpays across
 a whole trip. {EST}</p>""",
 "cols":"THE PROMPT · THE RIGHT ANSWER",
 "table_title":"Where American money leaks · the answer is a habit, not a budget",
 "rows":[
   ("<span class='opt'>\"Charge in USD or EUR?\" at a terminal or ATM</span><br><span class='gloss'>dynamic currency conversion — a markup dressed as a convenience</span>","always EUR"),
   ("<span class='opt'>Which ATM to use</span><br><span class='gloss'>Euronet in tourist zones = poor rates + fees; a bank ATM is better</span>","bank ATM"),
   ("<span class='opt'>Tipping at a taverna</span><br><span class='gloss'>US-style 18–20% overpays; local norm is round-up to 5–10%</span>","5–10%, cash"),
   ("<span class='opt'>Cash vs card day to day</span><br><span class='gloss'>card-friendly, but carry some cash for small tips and rural spots</span>","mostly card"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Always choose euros, use bank ATMs, and un-learn the
 20% tip.</strong> None of this is about spending less on the trip; it is about not leaking money at the
 seams an American reliably misses. {EST} Decline every dollar-conversion offer, skip the tourist-zone
 Euronet machines, and leave 5–10% in cash rather than a US-sized tip. {EST} These are small per-instance
 and real across a two-week trip — the rare kind of saving that costs you nothing to take.""",
 "for":["<b>always:</b> the terminal asks dollars-or-euros — euros, without exception; the 'convenience' is the markup",
        "<b>carry a little cash:</b> tips are left in cash, and some smaller or rural spots prefer it"],
 "against":["<b>don't over-correct:</b> Greece is genuinely card-friendly — you don't need to carry large cash, just some",
            "<b>don't under-tip to zero:</b> modest is the norm, but rounding up for good service is still customary and kind"],
 "note":f"""<b>{VOL} On the Sheet:</b> the dollar-euro rate moves daily and belongs there, not here. What
 stays here is the habit: decline conversion, and tip Greek, not American.""",
 "fig":None,
 "plate":"A01",
},
{
 "n":"08","rt":"","cat":"VALUE",
 "title":"Naxos or Paros — the island first-timers skip and shouldn't",
 "standfirst":"The two best-value islands in the Cyclades are the ones first-timers overlook for the famous pair. Choosing between them is a personality question, not a coin toss.",
 "lede":f"""<p class="dropcap">Naxos and Paros are neighbours, rivals, and the two best-value islands in the
 Cyclades — and they are exactly the ones first-timers skip and repeat visitors love. {EST} Both are
 beautiful, both far cheaper than Santorini and Mykonos, both wonderfully Greek; {EST} the non-obvious
 gain is that adding one of them to a trip lowers the cost and raises the rest, because it is where you
 actually slow down. The only real question is which, and that turns on personality, not merit.</p>
 <p>Naxos is the bigger of the two, with the best beaches of the group and a mountainous, interesting
 interior — the choice when you want range and a real island rather than only a harbour. {EST} Paros is
 the relaxed, well-connected middle choice: a chic harbour at Naoussa, pretty villages, and a gentle pace,
 and its connections make it easy to combine with the famous islands. {EST} Many first-timers do both; if
 you are picking one, the fork below is the fast way to decide. {EST}</p>""",
 "cols":"YOU WANT · THE ISLAND",
 "table_title":"Naxos vs Paros · a fork, not a ranking",
 "rows":[
   ("<span class='opt'>The best beaches and a bigger, varied island</span><br><span class='gloss'>a mountainous interior, working villages, room to roam</span>","Naxos"),
   ("<span class='opt'>A relaxed harbour and easy connections</span><br><span class='gloss'>Naoussa's scene, gentle pace, simple to pair with Santorini/Mykonos</span>","Paros"),
   ("<span class='opt'>Family value and space</span><br><span class='gloss'>bigger beaches and lower prices suit a family week</span>","Naxos"),
   ("<span class='opt'>You can't choose — and have the days</span><br><span class='gloss'>they're neighbours; do both, the hop is short</span>","both"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Add one of them — Naxos for range and beaches, Paros
 for pace and connections.</strong> Either one lowers the trip's cost and gives it its actual rest, which
 is why skipping both for a second famous island is the quiet overspend of a first trip. {EST} Naxos is the
 bigger, beachier, better-value base; Paros the relaxed, well-linked charmer. {EST} You will not regret
 including either; the regret is leaving both off the list.""",
 "for":["<b>then Naxos:</b> you want the best beaches, more island to explore, and the most value",
        "<b>then Paros:</b> you want an easy, relaxed base that connects simply to the famous islands"],
 "against":["<b>then reconsider:</b> you dropped both for a second headline island — you've paid the fame premium twice and lost the trip's rest",
            "<b>then both:</b> you have the days and can't decide — they're neighbours, and the hop between them is short (p.16)"],
 "note":f"""<b>Where to stay:</b> on either island a single central base reaches most of it (see Base, p.11).
 We give the base logic, not a hotel name.""",
 "fig":None,
},
{
 "n":"09","rt":"","cat":"DRIVING",
 "title":"Do you even want a car — and the permit Americans forget",
 "standfirst":"A rental car is a liability on some islands and the key to others. The mistake is deciding by habit — and forgetting the one document that makes it legal.",
 "lede":f"""<p class="dropcap">Whether to rent a car is not a single answer in Greece; it is an
 island-by-island call, and Americans get it wrong in both directions. On the compact, transfer-friendly
 islands, most people rely on pre-booked transfers and the occasional taxi rather than dealing with a car
 and its parking. {EST} On the large islands, a car is what makes the place reachable at all. Deciding by
 default — "we always rent" or "we never do" — is how you either fight for parking in Oia or strand
 yourself an hour from a Cretan beach.</p>
 <p>Then there is the document nobody mentions until it matters: to drive legally in Greece, an American
 needs an International Driving Permit alongside their licence. {EST} It is cheap and quick to obtain at
 home and effectively impossible to get once you have landed — which is exactly when people discover they
 needed it. On Santorini and Mykonos, parking in the caldera towns and near Mykonos town is tight, and many
 visitors who do drive use an ATV instead. {EST} On Crete and Naxos, the distances make a car worth the
 hassle. {EST}</p>""",
 "cols":"THE ISLAND · CAR OR NOT",
 "table_title":"Where a car helps and where it hurts · plus the paperwork",
 "rows":[
   ("<span class='opt'>Crete</span><br><span class='gloss'>distances demand it — a car is how you reach the island's spread-out highlights</span>","rent (+ IDP)"),
   ("<span class='opt'>Naxos</span><br><span class='gloss'>bigger island with an interior worth exploring — a car earns its keep</span>","worth it"),
   ("<span class='opt'>Santorini / Mykonos</span><br><span class='gloss'>tight parking in the towns; transfers + occasional taxi usually better</span>","usually skip"),
   ("<span class='opt'>The legal bit (any island, any American)</span><br><span class='gloss'>an International Driving Permit is required alongside your licence</span>","get it at home"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Rent on the big islands, skip it on the caldera
 islands — and get the IDP before you fly.</strong> On Crete and Naxos the distances make a car worth the
 hassle; {EST} on Santorini and Mykonos, tight town parking means transfers and the odd taxi usually beat
 driving. {EST} Whichever way you go, if you might drive at all, obtain the International Driving Permit at
 home {EST} — it is trivial there and unavailable here, and driving without it is the avoidable kind of
 trouble.""",
 "for":["<b>then rent:</b> you're on Crete or Naxos and want the beaches and villages beyond the main town — a car is the tool",
        "<b>then get the permit:</b> there's any chance you'll drive — the IDP is cheap at home and can't be sorted on arrival"],
 "against":["<b>then skip:</b> you're only on Santorini or Mykonos — parking is tight; transfers and taxis are simpler and often cheaper",
            "<b>then note:</b> you planned to rent but forgot the IDP — sort it before departure or plan not to drive"],
 "note":f"""<b>{OFF} Confirm before you fly:</b> the International Driving Permit requirement and how to obtain
 it in your state. It is an official rule, not a suggestion; the Sheet names where to get it.""",
 "fig":None,
},
{
 "n":"10","rt":"","cat":"ATHENS",
 "title":"Athens: how long, and is it the opener or the trip?",
 "standfirst":"Athens is where first-timers either linger too long or dismiss it too fast. It is neither the main event nor a layover — it is the opener, and it has an exact right length.",
 "lede":f"""<p class="dropcap">Most first-timers arrive with one of two wrong models of Athens: that it is a
 single-day checkbox on the way to the islands, or that it is a multi-day city break in its own right. The
 corpus's assembled answer is neither. Most travellers are itching for the islands, and Athens is a
 fantastic <em>opener</em>, not usually the main event of a first trip. {EST} The right length is two to
 three days — the sweet spot that sees the highlights without stalling the trip. {EST}</p>
 <p>What that time buys, in order: the Acropolis and the ancient core, the museums, and the neighbourhoods
 — Plaka, Monastiraki, Koukaki — that make the city more than its ruins. {EST} Beyond the Acropolis there
 is more ancient Athens than a day allows, which is the argument for the second and sometimes third day.
 {EST} And Athens is the hinge of the whole trip logistically: the port of Piraeus is about 20–30 minutes
 from the centre by metro, and the airport metro reaches the centre in about 40 minutes for a few euros —
 so the city is also your gateway to and from the islands. {EST}</p>""",
 "cols":"THE LENGTH · WHAT IT BUYS",
 "table_title":"Athens, sized right · the opener, not the trip",
 "rows":[
   ("<span class='opt'>One day</span><br><span class='gloss'>the Acropolis and little else — too rushed to do the city justice</span>","too short"),
   ("<span class='opt'>Two to three days</span><br><span class='gloss'>Acropolis, museums, the neighbourhoods — the highlights, unhurried</span>","the sweet spot"),
   ("<span class='opt'>Two to three days + a day trip</span><br><span class='gloss'>add Delphi or Cape Sounion if ancient history is your thing (p.28)</span>","if it fits"),
   ("<span class='opt'>Four+ days before the islands</span><br><span class='gloss'>most first-timers would rather spend the time on an island</span>","usually too long"),
 ],
 "verdict":f"""<span class="lab">The call</span><strong>Give Athens two to three days at the front, then go.</strong>
 It is the opener, not the finale: enough to see the Acropolis, the museums, and a neighbourhood or two
 properly, and to shake off the jet lag before the islands. {EST} Add a day trip only if ancient history
 pulls you and the days allow. {EST} Treat it as the trip's gateway — to the islands and home — and you have
 the city's role exactly right. Disagree on the day trips; the two-to-three-day frame is the durable part.""",
 "for":["<b>then two days:</b> you're eager for the islands — two days sees the essentials and keeps momentum",
        "<b>then three:</b> ancient history is a draw, or you want a day trip to Delphi/Sounion — the third day pays for it"],
 "against":["<b>then trim:</b> you've booked four or five days in Athens before any island — most first-timers would rather move that time to the coast",
            "<b>then don't skip it:</b> you planned Athens as a single arrival day — you'll miss the city that frames the trip; give it two"],
 "note":f"""<b>{VOL} Confirm in your travel week:</b> Acropolis ticket timing and any strike days — Athens
 sees occasional transport strikes. The Sheet names where to check both.""",
 "fig":None,
},
]
