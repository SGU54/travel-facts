from playwright.sync_api import sync_playwright
import design2, maps
figs = [("cover",maps.COVER()),("asym",maps.FIG_ASYMMETRY()),("cyc",maps.FIG_CYCLADES()),
        ("crete",maps.FIG_CRETE()),("ferry",maps.FIG_FERRYFLY()),("season",maps.FIG_SEASON())]
body = f'<div class="cover" style="width:8.5in;height:11in;margin:0 auto">{maps.COVER()}</div>'
for name,svg in figs[1:]:
    body += f'<div class="fig" style="width:660px;margin:20px auto;background:{design2.TOK["paper"]};padding:10px">{svg}</div>'
html = f'<!doctype html><html><head><meta charset=utf-8><style>{design2.CSS} body{{margin:0;background:#999}}</style></head><body>{body}</body></html>'
open("preview.html","w").write(html)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":816,"height":1056},device_scale_factor=2)
    pg.goto("file://"+__import__("os").path.abspath("preview.html")); pg.wait_for_timeout(900)
    pg.screenshot(path="cover.png", clip={"x":0,"y":0,"width":816,"height":1056})
    # figures strip
    pg.screenshot(path="figs.png", full_page=True)
    b.close()
print("rendered cover.png + figs.png")
