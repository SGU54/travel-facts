# content2.py — the chapters around the decisions: timing, set pieces, eating, money leaks,
# where to stay, the days, day trips, failure modes, the wallet card, back matter, closing,
# and the Field Sheet. All corpus-sourced and marked.
from prose import mk
EST = mk("est"); OFF = mk("off"); VOL = mk("vol"); SUR = mk("sur")

# ---------------- BEFORE YOU FLY ----------------
BEFORE = f"""
<div class="eyebrow">Before you fly — the checklist with deadlines</div>
<h2 class="sec">What to settle at home, and by when</h2>

<p>A first Greek trip has a short list of things that are trivial to arrange at home and painful or
impossible to fix on arrival. Do these before you fly, in roughly this order.</p>

<ul class="tick">
<li><b>Entry — do it once, weeks ahead.</b> US citizens can visit visa-free for tourism for up to 90 days
in any 180-day period, as part of the Schengen Area. {OFF} A new pre-travel authorisation, ETIAS, is being
introduced for visa-exempt visitors; confirm current status and apply if required well before departure.
The Field Sheet names the official source.</li>
<li><b>The driving permit — before you leave, or not at all.</b> If there is any chance you'll drive, get an
International Driving Permit at home. {EST} It cannot be sorted after you land.</li>
<li><b>The riskiest legs — book the structure, not just the seats.</b> Lock your island sequence so the
fast-boat leg doesn't fall on your flight day (Decision 01), and build a buffer before the international
flight. {EST}</li>
<li><b>The flight home leg — decide ferry vs fly now.</b> The leg off your final island back to Athens is
insurance; choose the conventional boat or a flight, not the fast catamaran on departure morning (Decision 05).</li>
<li><b>Connectivity — arrange before you land.</b> An eSIM set up at home means you arrive connected; buy it
before departure rather than hunting Wi-Fi at the airport. {EST}</li>
<li><b>Season awareness — check what's open.</b> If you're travelling at the edges of the season, confirm that
your islands' boats and services are running; some thin out or close (see Timing, below). {EST}</li>
</ul>
"""

# ---------------- DAY ZERO ----------------
DAYZERO = f"""
<div class="eyebrow">Day zero — the arrival nobody writes</div>
<h2 class="sec">Your first hours in Athens</h2>

<p class="dropcap">The most anxious hours of the trip are the ones no itinerary covers: landing, jet-lagged,
and getting from the airport into the city or on to the port. Greece runs about seven hours ahead of US
Eastern Time — more from the West Coast — so you will arrive tired and out of sync, and the day works best
as a soft landing rather than a sightseeing sprint. {EST}</p>

<p>The mechanics are simple and cheap. From Athens airport, the Metro (Line 3) reaches central Athens —
Syntagma and Monastiraki — in about 40 minutes for a flat fare, the simplest option if your hotel is near a
central station. {EST} A taxi takes 30–45 minutes depending on traffic, on a fixed daytime tariff; the X95
bus runs 24 hours and takes longer. {EST} If you're heading straight for the islands, the port of Piraeus is
about 20–30 minutes from the centre by metro. {EST}</p>

<p>Two arrival rules save a first evening. First, don't schedule an island ferry for your arrival day — jet
lag and a missed connection are a bad first act; give yourself a night in Athens first. Second, if your
hotel is in the caldera towns of Santorini later in the trip, pre-book a transfer from the port: the towns
are a steep climb, taxis are limited, and the last thing you want after travel is to be stranded with
luggage. {EST}</p>
"""

# ---------------- TIMING / SEASON ----------------
TIMING = f"""
<div class="eyebrow">Timing — the rhythm of the year</div>
<h2 class="sec">When to go, and the seasonal trap</h2>

<p class="dropcap">Season is a first-order decision in Greece, not an afterthought, because it moves four things
at once — weather, crowds, prices, and whether the boats run reliably. For most first-timers the shoulder
seasons, late spring (May–June) and early fall (September–early October), are the sweet spot: warm,
swimmable seas, manageable crowds, and gentler prices. {EST} They also line up neatly with a first trip's
logic, since the shoulder months bracket the summer peak without its heat or its wind.</p>

<p>The trap is the peak itself. July and August bring the strongest crowds and the highest prices — and the
meltemi, the northerly wind that disrupts fast-ferry crossings exactly when the most people are trying to
make them. {EST} The figure opposite lays the year out in bands: when the Cyclades are fully open, where the
shoulder value sits, and when the wind and the crowds peak together. The lesson is that peak season is not
simply "busier" — it is the one window where the sequencing risk of this whole book is at its sharpest.</p>

<p>At the season's edges the calculus flips the other way: more flexibility and lower prices, but thinner
schedules, so you must check the current timetable rather than assume a sailing runs. {EST} Some island
services and seasonal boat trips close entirely outside the core months. {EST} The shoulder is the
first-timer's friend; the shoulder's edge is where you trade crowds for the need to double-check everything.</p>
"""

# ---------------- SET PIECES ----------------
SETPIECES = f"""
<div class="eyebrow">The set pieces — the operations you can't wing</div>
<h2 class="sec">The Acropolis, the sunset, the port</h2>

<p class="dropcap">A first trip has a few unavoidable operations where the difference between a good memory and a
bad one is order-of-operations, not luck. Three are worth planning as operations rather than sights.</p>

<h3 class="sub">The Acropolis</h3>
<p>Go at opening or in the late afternoon to beat the heat and the crowds; the middle of a summer day is the
worst of both. {EST} It is the anchor of ancient Athens, but not the whole of it — there is more beyond it
than a single visit allows, which is part of why two to three days in Athens earns its place (Decision 10).
{EST} Ticket timing and occasional strike days are worth confirming in your travel week (Field Sheet).</p>

<h3 class="sub">The Santorini sunset</h3>
<p>The sunset is genuinely spectacular and lives up to the hype for most first-timers. {EST} The one useful
piece of local knowledge — which the island's own guides state plainly — is that it is just as beautiful from
other caldera-facing spots as from the single most crowded one, so you can trade the crush for a quieter perch
without losing the view. {EST} Many visitors base in Fira or a beach town and come up to Oia for it; where you
sleep shapes how easy that is (Decision 03).</p>

<h3 class="sub">The port</h3>
<p>Piraeus is the launch point for most island trips, about 20–30 minutes from central Athens by metro. {EST}
Confirm which port your ferry actually uses — Piraeus, Rafina, or Lavrio — and arrive at least 30–60 minutes
before departure, more in peak season. {EST} On the islands, remember that the port is often a steep, slow
drive from the towns, so build transfer time into every hop rather than assuming the dock is the destination.
{EST}</p>
"""

# ---------------- EATING ----------------
EATING = f"""
<div class="eyebrow">Eating — the rule that outlives the list</div>
<h2 class="sec">How to eat well without a single restaurant name</h2>

<p class="dropcap">We will not hand you a list of restaurants, because a named restaurant is a guess with a
byline that is wrong by spring. What outlasts any list is the way Greeks eat, and adopting it does more for a
first trip than any address. Greek food is a bargain by Western European standards, especially away from the
tourist hotspots and the famous islands' view restaurants — which is precisely where the value leaks. {EST}</p>

<p>The taverna is the unit of a good trip. Order to share, in the middle of the table, rather than a plate
each; take your time, because the meal is the evening, not a stop before it. On tipping, the rule from Money
(Decision 07) applies: round up or leave 5–10% in cash for good service, with no American-style 18–20%
expectation. {EST} House wine is usually the right call — Greek wine rewards the beginner who orders local —
and a few-euro gyros is a legitimate meal, not a compromise. {EST}</p>

<p>The one habit that separates a good eating trip from a mediocre one is geographic: eat where locals eat,
a street back from the view. The famous-island view restaurants charge for the view; the taverna in the
working village a short walk away serves the same tradition for a fraction. {EST} That is the rule, and unlike
a restaurant name, it does not expire.</p>
"""

# ---------------- MONEY LEAKS (short essay reinforcing Decision 07) ----------------
MONEY = f"""
<div class="eyebrow">Money — where it actually leaks</div>
<h2 class="sec">The levers that move the total</h2>

<p class="dropcap">A Greek trip's cost swings on a few big levers, so two travellers can spend wildly different
amounts on the "same" trip. {EST} The honest way to budget is to pull the levers deliberately rather than chase
a per-day figure that means nothing. The levers, in order of impact: which islands (the famous pair cost
multiples of the value islands), when you go (shoulder versus peak), how you travel (ferries versus flights,
guesthouses versus caldera suites), and the transatlantic flight, which is often the single biggest line item.
{EST}</p>

<p>A budget trip leans on the value levers — shoulder season, value islands, guesthouses, deck-class ferries,
and taverna meals. A mid-range trip mixes comfortable hotels, a balance of ferries and flights, and a famous
island or two. A splurge means caldera suites and private transfers. {EST} The point is that the shape of the
trip, not the discipline of the traveller, determines the total — which is why the biggest saving available to
a first-timer is structural (value island instead of a second famous one) rather than a matter of skipping
coffees.</p>

<p>On the ground, the leaks are the ones in Decision 07: the dollar-conversion prompt, the tourist-zone
Euronet ATM, and the American-sized tip. {EST} None of these is about the price of Greece; all three are about
not handing money away at the seams. Current figures live on the Field Sheet; the levers and the leaks live
here, because they don't change.</p>
"""

# ---------------- WHERE TO STAY (assessments on identical criteria) ----------------
STAY = f"""
<div class="eyebrow">Where to stay — the areas, assessed alike</div>
<h2 class="sec">Six bases, one set of criteria</h2>

<p class="dropcap">We assess areas, not hotels. Each base below is judged on the same three questions: what it
puts within reach, what it costs you in convenience, and who it suits. Pick the area; the room is a detail
underneath it (Decision 03).</p>

<ul class="tick">
<li><b>Santorini — the caldera towns (Oia, Fira, Imerovigli).</b> Reach: the view and the sunset you came for.
Cost: a steep, slow climb from the port and premium prices. Suits: the finale, for a night or two, with the
rest of the stay somewhere sensible. {EST}</li>
<li><b>Athens — the central neighbourhoods (Plaka, Monastiraki, Koukaki).</b> Reach: the Acropolis, the
museums, the metro to port and airport. Cost: little — this is the practical, walkable heart. Suits: every
first-timer, for the two-to-three-day opener. {EST}</li>
<li><b>Crete — a western base (Chania).</b> Reach: Chania's old town, the lagoon beaches, the gorges. Cost: the
east of the island becomes a driving day. Suits: most first-timers to Crete — the island's greatest hits in its
most scenic corner. {EST}</li>
<li><b>Crete — a central base (Heraklion).</b> Reach: Knossos, the archaeological museum, central beaches. Cost:
the far west is a long drive. Suits: history-first travellers, or half of a two-base week. {EST}</li>
<li><b>Mykonos — town versus the beaches.</b> Reach (town): the scene, the walkable lanes, easy sea-taxis to
beaches. Reach (beach): quiet and the water on your doorstep. Cost: tight parking near town. Suits: energy in
town, calm at a beach — pick your priority. {EST}</li>
<li><b>Naxos / Paros — the main town.</b> Reach: compact enough that one central base reaches most of the island;
best beaches and value on Naxos, a relaxed harbour on Paros. Cost: minimal. Suits: the trip's actual rest
(Decision 08). {EST}</li>
</ul>
"""

# ---------------- THE PLAN (days as operations) ----------------
PLAN = f"""
<div class="eyebrow">The plan — the days, as operations</div>
<h2 class="sec">A week that works, and how to stretch it</h2>

<p class="dropcap">The formats below are not itineraries to follow hour by hour; they are the shapes that
survive contact with the ferry network. Each ends by flying back to Athens to connect home — the leg the wind
can't cancel (Decision 06).</p>

<h3 class="sub">Five days — resist the hop</h3>
<p>With a short trip, resist island-hopping entirely: Athens (2 nights) plus one island (2–3 nights), or a
single island for the whole trip. {EST} Athens and Santorini in five days — two nights in the city, three on
the island — is the classic version, and its strength is its simplicity: two great places, one easy flight
between them, no second move to eat a day. {EST}</p>

<h3 class="sub">Seven days — the sweet spot</h3>
<p>A week is the sweet spot for Athens plus two islands: typically one relaxed island and one showstopper.
{EST} Athens (2 nights) → an easy island like Paros or Naxos (2–3 nights) → Santorini (3 nights) → fly back to
Athens. {EST} Adding a second island beyond this eats a day and adds cancellation risk before your flight home,
which is the trade the sequence chapter warns against. {EST}</p>

<h3 class="sub">Ten to fourteen days — add depth, not just islands</h3>
<p>Ten days comfortably fits Athens plus two islands at a relaxed pace, or three if you keep the legs short.
{EST} Two weeks lets you add a third island, or fold in Crete via a short flight for variety, while still
keeping a humane pace. {EST} The temptation to add Crete or the mainland to a ten-day trip is where it starts
to feel tight; give Crete its own room or its own trip. {EST}</p>
"""

# ---------------- DAY TRIPS ----------------
DAYTRIPS = f"""
<div class="eyebrow">The extra day — day trips, verdict first</div>
<h2 class="sec">If Athens gets a third day</h2>

<p class="dropcap"><strong>Verdict: worth it only if ancient history genuinely pulls you, and only with the
days to spare.</strong> A day trip from Athens is a real day spent, so it competes directly with an extra island
day — and for most first-timers the island wins. If history is the draw, two options stand out.</p>

<ul class="tick">
<li><b>Cape Sounion and the Temple of Poseidon.</b> A half-day along the coast to a clifftop temple, best at
late afternoon for the light. KTEL buses run from Athens along the coast — the budget option — but check return
times carefully so you're not stranded after dark; a car (with the IDP) gives a scenic, flexible coastal drive.
{EST}</li>
<li><b>Delphi.</b> A full day inland to one of the great ancient sites, more of a commitment than Sounion and
better suited to travellers for whom the ruins are the point rather than a box. {EST}</li>
</ul>

<p>Either can be done in a day, but neither is free: it is the day you did not spend on an island. Add one only
if the sequence has slack and ancient Greece is a reason you came. {EST}</p>
"""

# ---------------- FAILURE MODES (organised BY CONSEQUENCE) ----------------
FAILURE = f"""
<div class="eyebrow">Failure modes — organised by what it costs you</div>
<h2 class="sec">Twenty ways a first trip goes wrong, sorted by the damage</h2>

<p class="dropcap">A website of articles can warn you about mistakes one at a time. What it cannot do is sort them
by consequence, so you know which are catastrophic and which are merely annoying. Here they are, worst first.</p>

<h3 class="sub">Costs you the trip, or a flight home</h3>
<ul class="tick">
<li><b>Scheduling the island-to-airport ferry on your departure day.</b> A wind-cancelled fast boat takes your
flight with it. End on an airport island and fly, or leave a buffer day. {EST}</li>
<li><b>Assuming the fast ferry always runs.</b> In July and August the meltemi cancels the catamarans first;
the plan that depends on one is a plan with a single point of failure. {EST}</li>
<li><b>No buffer before the international flight.</b> One cancelled sailing and you are rebooking a transatlantic
ticket. A spare day converts a crisis into an inconvenience. {EST}</li>
<li><b>Treating Crete as a two-night hop.</b> It is a small country; folded into an island week it either eats
the week or gets nothing. Give it its own trip. {EST}</li>
</ul>

<h3 class="sub">Costs you a day (or several)</h3>
<ul class="tick">
<li><b>Packing five islands into a week.</b> Every move is a half-day of ports and transfers; the trip becomes
transit. Two islands a week, three in ten days. {EST}</li>
<li><b>Hotel-hopping a big island nightly.</b> On Crete especially, the distances punish it — you book driving
days without noticing. One base per region. {EST}</li>
<li><b>Ferrying the long legs to save money.</b> Athens–Santorini by boat is five to eight hours against a
45-minute flight; the "saving" is most of a day. {EST}</li>
<li><b>Under-estimating transfer time on each island.</b> The port is often a steep, slow drive from town;
budget it into every hop. {EST}</li>
<li><b>Scheduling an island ferry for your arrival day.</b> Jet lag plus a missed connection is a bad first act;
overnight in Athens first. {EST}</li>
<li><b>Four-plus days in Athens before the islands.</b> Two to three is the sweet spot; the rest is time most
first-timers would rather spend on the coast. {EST}</li>
</ul>

<h3 class="sub">Costs you money</h3>
<ul class="tick">
<li><b>Choosing dollars at the card reader.</b> Dynamic currency conversion is a markup dressed as convenience —
always choose euros. {EST}</li>
<li><b>Using tourist-zone Euronet ATMs.</b> Poor rates and fees; a bank ATM is better. {EST}</li>
<li><b>Tipping American-style.</b> 18–20% overpays across a whole trip; the local norm is round-up to 5–10%.
{EST}</li>
<li><b>Two famous islands instead of one famous, one value.</b> You pay the fame premium twice and skip the
trip's actual rest. {EST}</li>
<li><b>Eating on the view.</b> Famous-island view restaurants charge for the view; a taverna a street back serves
the same tradition for less. {EST}</li>
</ul>

<h3 class="sub">Costs you comfort or the experience</h3>
<ul class="tick">
<li><b>The fast boat with a sensitive stomach.</b> Catamarans are bumpy in chop; the conventional ferry is the
gentler ride. {EST}</li>
<li><b>The Acropolis at midday in summer.</b> Heat and crowds at their worst; go at opening or late afternoon.
{EST}</li>
<li><b>The most crowded sunset spot.</b> The view is just as good from quieter caldera-facing perches. {EST}</li>
<li><b>Renting a car on Santorini or Mykonos.</b> Tight town parking makes transfers and taxis simpler; save the
car for the big islands. {EST}</li>
<li><b>Forgetting the International Driving Permit.</b> Required for Americans and unobtainable on arrival —
sort it at home or plan not to drive. {EST}</li>
</ul>
"""

# ---------------- WALLET CARD ----------------
WALLET = f"""
<div class="eyebrow">The wallet card — print it, carry it</div>
<h2 class="sec">The whole book on one card</h2>

<div class="wallet">
<div class="wh"><span>GREECE — THE CALLS THAT MATTER</span><span>greeceforamericans</span></div>
<dl>
<dt>SEQUENCE</dt><dd>Athens → value island → <b>Santorini last</b>. End on an airport island; <b>fly</b> back to Athens.</dd>
<dt>THE FLIGHT LEG</dt><dd>Never a fast boat on departure day. Conventional ferry or a flight, <b>+ a buffer day</b>.</dd>
<dt>THE WIND</dt><dd>July–Aug meltemi cancels <b>fast boats first</b>. Sensitive stomach → conventional, always.</dd>
<dt>FLY vs FERRY</dt><dd>Fly the long legs (Athens–Santorini ~45min). Ferry the short Cyclades hops.</dd>
<dt>ISLANDS</dt><dd>One famous + one value. <b>Naxos</b> (beaches/value) or <b>Paros</b> (relaxed/connected).</dd>
<dt>CRETE</dt><dd>One region, several nights. Distance, not hours, is the limit. Its own trip.</dd>
<dt>MONEY</dt><dd>Card reader → <b>always euros</b>. Bank ATM, not Euronet. Tip <b>5–10%</b>, not 20%.</dd>
<dt>CAR</dt><dd>Rent on Crete/Naxos; skip on Santorini/Mykonos. <b>IDP required</b> — get it at home.</dd>
<dt>ATHENS</dt><dd><b>2–3 days</b>, the opener. Acropolis at opening or late afternoon. Piraeus ~20–30min by metro.</dd>
<dt>ENTRY</dt><dd>90 days visa-free (Schengen). Check <b>ETIAS</b> before you fly.</dd>
</dl>
</div>
"""

# ---------------- BACK MATTER (refusals) ----------------
BACKMATTER = f"""
<div class="eyebrow">What this book won't tell you — and why that's the point</div>
<h2 class="sec">The refusals are the product</h2>

<p class="dropcap">This book withholds four things on purpose. Each refusal exists because the alternative would
be fake certainty — and fake certainty is exactly what a paid manual has no right to sell. What we give you
instead outlasts what we withhold.</p>

<div class="refuse">
<div class="r"><div class="rk">We won't name a hotel.</div><div class="rv">A room we praise is stale by spring, and one
we haven't slept in is a guess with a byline. What we give instead — which <em>area</em> to base in, and why —
doesn't expire (Decision 03, Where to Stay).</div></div>
<div class="r"><div class="rk">We won't name a restaurant.</div><div class="rv">A named restaurant is a data point that
rots in a season and that you can get free anywhere. The <em>rule</em> for finding the right one — eat a street
back from the view, order to share, tip Greek — outlives any list (Eating).</div></div>
<div class="r"><div class="rk">We won't print a current price.</div><div class="rv">A live number in a book is a lie with
a long shelf life. Prices live on the dated Field Sheet, with the official source named, so you check them in
your travel week rather than trust our press date.</div></div>
<div class="r"><div class="rk">We won't republish anyone's ratings.</div><div class="rv">Aggregated scores are
someone else's data and someone else's liability, and they change under you. Our judgments are our own, marked,
and dated — you can weigh them, and you can disagree.</div></div>
</div>

<p style="margin-top:14px">If any of that reads as a limitation, read it again: everything we refuse is
something that would have been wrong by the time you travelled. Everything we keep is built to still be true.
That is the trade this book makes, and it is the whole of why it costs money.</p>
"""

# ---------------- CLOSING ----------------
CLOSING = f"""
<div class="eyebrow">Closing</div>
<h2 class="sec">The reward for getting the order right</h2>

<p class="dropcap">Do the boring parts well — the sequence, the buffer, the boat off the last island — and the
trip gives you back the thing the planning was for. A morning ferry across a calm Aegean with a coffee on the
open deck; the caldera at Santorini earning its reputation because you arrived rested and on time rather than
frazzled and behind; a taverna dinner in a working village a street back from the view, the meal unfolding into
the evening the way it is meant to.</p>

<p>None of that is luck. It is what is left when the logistics have been handled in advance, so the trip is free
to be a trip. Greece is generous to travellers who get the order right and unforgiving to those who leave it to
chance — and the whole of this book is simply the order, drawn from facts that were always free and joined here
for the first time. Go in the right sequence, and come up for air.</p>
"""

# ================= FIELD SHEET =================
FIELDSHEET = f"""
<div class="eyebrow">The Field Sheet — the dated annex</div>
<h1 class="t">Field Sheet<span class="sub">The figures that move — confirm in your travel week</span></h1>
<div class="standfirst">Everything in the Book ages slowly. Everything here does not. This sheet carries only the
volatile figures, each with the official place to re-check it. When the Sheet and the Book disagree, the Sheet
wins.</div>

<h3 class="sub">Confirm before you fly — official rules</h3>
<table class="fs">
<tr><th>Item</th><th>What to confirm</th><th>Where to check</th></tr>
<tr><td>Entry / visa</td><td class="v">◆ status</td><td class="src">90 days visa-free in Schengen for US tourists; confirm current terms — official EU / Schengen visa information</td></tr>
<tr><td>ETIAS authorisation</td><td class="v">◆ status</td><td class="src">Whether the pre-travel authorisation is required for your dates, and apply if so — official ETIAS site</td></tr>
<tr><td>Passport validity</td><td class="v">◆ rule</td><td class="src">Schengen passport-validity requirement — official EU / your passport authority</td></tr>
<tr><td>Driving permit</td><td class="v">◇ IDP</td><td class="src">International Driving Permit requirement and how to obtain it in your state — official issuing body</td></tr>
</table>

<h3 class="sub">Confirm in your travel week — schedules &amp; prices</h3>
<table class="fs">
<tr><th>Item</th><th>Why it moves</th><th>Where to check</th></tr>
<tr><td>Ferry timetables &amp; port</td><td class="src">Sailings are seasonal and change year to year; fast boats cancel in high wind; your port (Piraeus / Rafina / Lavrio) depends on the route</td><td class="src">The ferry operators' current schedules for your legs, and your booking confirmation</td></tr>
<tr><td>Domestic flight fares &amp; times</td><td class="src">Move with season and demand</td><td class="src">The airlines' current schedules (Athens hub)</td></tr>
<tr><td>Acropolis tickets &amp; hours</td><td class="src">Timed entry; seasonal hours</td><td class="src">The official Acropolis / ministry ticketing site</td></tr>
<tr><td>Strike days (transport)</td><td class="src">Occasional, announced short-term</td><td class="src">Local news / official transport notices in your travel week</td></tr>
<tr><td>USD–EUR rate</td><td class="src">Moves daily</td><td class="src">Any live rate source; always choose euros at the reader</td></tr>
<tr><td>Seasonal beach access / boat trips</td><td class="src">Some close outside core months (e.g. Elafonisi, Balos)</td><td class="src">Local operators for your travel dates</td></tr>
<tr><td>Daily budget bands</td><td class="src">Swing on island, season, and style — no single number is meaningful</td><td class="src">Price your own islands and dates against the levers in Money (p.24)</td></tr>
</table>

<p class="note" style="margin-top:16px"><b>Survey method {SUR}:</b> the structural facts in the Book are drawn
from the greeceforamericans published corpus and cross-checked for internal consistency. This Sheet lists what we
deliberately did <em>not</em> fix in print because it moves; confirm each against the official source named before
you rely on it. Edition One.</p>
"""
