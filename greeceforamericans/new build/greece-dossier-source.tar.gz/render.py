import os
from pypdf import PdfReader, PdfWriter
from playwright.sync_api import sync_playwright

HERE = os.path.abspath(os.path.dirname(__file__))
html_path = os.path.join(HERE, "dossier3.html")
pdf_path = os.path.join(HERE, "dossier.pdf")
cover_pdf = os.path.join(HERE, "_cover.pdf")
body_pdf = os.path.join(HERE, "_body.pdf")

FOOTER = (
    '<div style="width:100%;font-family:\'IBM Plex Mono\',monospace;font-size:7px;'
    'letter-spacing:2px;color:#8B9AA1;text-align:center;padding:0 0 6px;">'
    'GREECE, IN ORDER. · greeceforamericans · <span class="pageNumber"></span></div>'
)
BLANK = '<div></div>'

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 816, "height": 1056}, device_scale_factor=2)
    pg.goto("file://" + html_path)
    pg.wait_for_timeout(1200)

    # full doc, with folios, to a temp file
    pg.pdf(path=body_pdf, width="8.5in", height="11in", print_background=True,
           prefer_css_page_size=True, display_header_footer=True,
           header_template=BLANK, footer_template=FOOTER,
           margin={"top": "0in", "bottom": "0in", "left": "0in", "right": "0in"})

    # full doc, NO folios, to grab a clean cover page 1
    pg.pdf(path=cover_pdf, width="8.5in", height="11in", print_background=True,
           prefer_css_page_size=True, display_header_footer=False,
           margin={"top": "0in", "bottom": "0in", "left": "0in", "right": "0in"})
    b.close()

# merge: clean cover (page 1 of cover_pdf) + folio'd interior (pages 2..n of body_pdf)
cov = PdfReader(cover_pdf)
bod = PdfReader(body_pdf)
w = PdfWriter()
w.add_page(cov.pages[0])                 # cover, no folio
for i in range(1, len(bod.pages)):        # interior, with folios
    w.add_page(bod.pages[i])
with open(pdf_path, "wb") as f:
    w.write(f)

for tmp in (cover_pdf, body_pdf):
    try: os.remove(tmp)
    except OSError: pass

sz = os.path.getsize(pdf_path)
print(f"dossier.pdf written · {sz:,} bytes · {len(PdfReader(pdf_path).pages)} pages (cover folio suppressed)")

