# maps.py — every figure is our own artwork, computed from real public coordinates.
# Palette is imported from design2 (bug log #10: never redefine the palette here).
import math
from design2 import TOK as C

# ---- real public coordinates (ports / island centres) ----
GEO = {
 "Piraeus":   (37.9470, 23.6370),
 "Athens":    (37.9838, 23.7275),
 "Rafina":    (38.0250, 24.0080),
 "Mykonos":   (37.4460, 25.3290),
 "Delos":     (37.3930, 25.2710),
 "Naxos":     (37.1070, 25.3760),
 "Paros":     (37.0850, 25.1500),
 "Ios":       (36.7230, 25.2830),
 "Santorini": (36.4130, 25.4320),
 "Milos":     (36.7440, 24.4270),
 "Heraklion": (35.3390, 25.1330),
 "Chania":    (35.5120, 24.0180),
}

def km(a, b):
    (la1, lo1), (la2, lo2) = GEO[a], GEO[b]
    R = 6371; p = math.pi / 180
    dx = (lo2 - lo1) * p * math.cos((la1 + la2) * p / 2)
    dy = (la2 - la1) * p
    return R * math.hypot(dx, dy)

# ---------- collision-safe label placement (d-draw.md) ----------
class _Boxes:
    def __init__(self): self.b = []
    def _hit(self, x0, y0, x1, y1):
        return any(min(x1, a1) - max(x0, a0) > 1 and min(y1, c1) - max(y0, c0) > 1
                   for (a0, c0, a1, c1) in self.b)
    def add(self, x0, y0, x1, y1): self.b.append((x0, y0, x1, y1))
    def place(self, x, y, text, fs, anchor="start", tries=None):
        w = len(text) * fs * 0.56; h = fs
        if tries is None:
            tries = [(0, 0, anchor), (0, -fs - 3, anchor), (0, fs + 5, anchor),
                     (0, 0, "end" if anchor == "start" else "start"),
                     (0, fs + 7, "middle"), (0, -fs - 9, "middle")]
        for dx, dy, an in tries:
            xx, yy = x + dx, y + dy
            x0 = xx if an == "start" else (xx - w / 2 if an == "middle" else xx - w)
            if not self._hit(x0, yy - h * 0.78, x0 + w, yy + h * 0.24):
                self.add(x0, yy - h * 0.78, x0 + w, yy + h * 0.24); return xx, yy, an
        x0 = x if anchor == "start" else (x - w / 2 if anchor == "middle" else x - w)
        self.add(x0, y - h * 0.78, x0 + w, y + h * 0.24); return x, y, anchor

# project lat/lon -> svg xy inside a box, with margins; y flips (north up)
def _proj(names, x0, y0, w, h, pad=0):
    las = [GEO[n][0] for n in names]; los = [GEO[n][1] for n in names]
    la_min, la_max = min(las), max(las); lo_min, lo_max = min(los), max(los)
    # keep aspect roughly correct for the latitude
    cx = (lo_min + lo_max) / 2; cy = (la_min + la_max) / 2
    lon_scale = math.cos(cy * math.pi / 180)
    span_lo = max((lo_max - lo_min) * lon_scale, 1e-6)
    span_la = max(la_max - la_min, 1e-6)
    def xy(n):
        la, lo = GEO[n]
        fx = ((lo - lo_min) * lon_scale) / span_lo
        fy = (la - la_min) / span_la
        return (x0 + pad + fx * (w - 2 * pad), y0 + h - pad - fy * (h - 2 * pad))
    return xy

def _hdr(vb_w, x, y, txt):
    return (f'<text x="{x}" y="{y}" font-family="IBM Plex Mono" font-size="8.5" '
            f'letter-spacing="2.4" fill="{C["soft"]}" text-transform="uppercase">{txt}</text>')

# ===================================================================
# COVER — the organising fact: the route graph the meltemi governs.
# Real nodes, real edges, real sea distances. Unclonable without the data.
# ===================================================================
def COVER():
    W, H = 816, 1056
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<rect width="{W}" height="{H}" fill="{C["paper"]}"/>')

    # --- the meltemi as the ground the page sits on: faint NNE streamlines ---
    # meltemi blows from the north / NNE across the Aegean; draw it behind everything, light.
    import random
    random.seed(7)
    s.append('<g opacity="0.5">')
    for i in range(26):
        x = 40 + i * 30
        # gentle curved streamline flowing down-left (northerly)
        pts = []
        yy = -20; xx = x
        while yy < H + 20:
            xx -= 2.1 + 0.5 * math.sin(yy / 90.0 + i)
            yy += 26
            pts.append(f"{xx:.1f},{yy:.1f}")
        s.append(f'<polyline points="{" ".join(pts)}" fill="none" '
                 f'stroke="{C["water"]}" stroke-width="1.0"/>')
    s.append('</g>')

    # --- the route graph, computed ---
    names = ["Piraeus", "Mykonos", "Naxos", "Paros", "Ios", "Santorini"]
    box_x, box_y, box_w, box_h = 92, 250, 632, 560
    xy = _proj(names, box_x, box_y, box_w, box_h, pad=54)

    # edges of the canonical first-timer sequence, with real distances
    seq = [("Piraeus", "Mykonos"), ("Mykonos", "Naxos"),
           ("Naxos", "Santorini"), ("Santorini", "Piraeus")]
    # the "gamble" edge — a fast-boat leg on the day you fly — drawn as the warning
    P = {n: xy(n) for n in names}

    # supporting (lighter) alternative connections
    for a, b in [("Naxos", "Paros"), ("Paros", "Santorini"), ("Naxos", "Ios"),
                 ("Ios", "Santorini")]:
        (x1, y1), (x2, y2) = P[a], P[b]
        s.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                 f'stroke="{C["soft"]}" stroke-width="0.9" stroke-dasharray="2 5" opacity="0.7"/>')

    # the spine sequence — solid, weighted, the argument on top
    for a, b in seq[:-1]:
        (x1, y1), (x2, y2) = P[a], P[b]
        s.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                 f'stroke="{C["accent"]}" stroke-width="2.6"/>')
        d = km(a, b)
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        # if the leg is steep (near-vertical), push the label to the right of the line
        vertical = abs(x2 - x1) < abs(y2 - y1)
        if vertical:
            s.append(f'<text x="{mx + 12:.1f}" y="{my:.1f}" font-family="IBM Plex Mono" '
                     f'font-size="10" fill="{C["deep"]}" text-anchor="start">{d:.0f} km</text>')
        else:
            s.append(f'<text x="{mx:.1f}" y="{my - 8:.1f}" font-family="IBM Plex Mono" '
                     f'font-size="10.5" fill="{C["deep"]}" text-anchor="middle">{d:.0f} km</text>')

    # the return leg to Piraeus (the fixed flight) — gilt, dashed, the commit line
    (x1, y1), (x2, y2) = P["Santorini"], P["Piraeus"]
    s.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
             f'stroke="{C["gilt"]}" stroke-width="2.0" stroke-dasharray="7 5"/>')
    mx, my = (x1 + x2) / 2, (y1 + y2) / 2
    s.append(f'<text x="{mx + 8:.1f}" y="{my:.1f}" font-family="IBM Plex Mono" '
             f'font-size="9.5" fill="{C["gilt"]}" transform="rotate(-58 {mx:.1f} {my:.1f})">'
             f'fly home</text>')

    # nodes + labels (collision-safe, offset clearly from the dot)
    boxes = _Boxes()
    order_num = {"Piraeus": "", "Mykonos": "1", "Naxos": "2", "Santorini": "3"}
    for n in names:
        x, y = P[n]
        r = 7 if n in ("Piraeus", "Santorini") else 5.5
        fill = C["accent"] if n in order_num else C["soft"]
        s.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r}" fill="{fill}"/>')
        if n == "Piraeus":
            s.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r+4}" fill="none" '
                     f'stroke="{C["accent"]}" stroke-width="1.4"/>')
        # decide side: label sits left of dot for right-hand nodes, right for left-hand nodes
        right_side = x < box_x + box_w * 0.55
        gap = r + 8
        if right_side:
            lx0, an = x + gap, "start"
        else:
            lx0, an = x - gap, "end"
        lx, ly, an = boxes.place(lx0, y + 5, n, 20, anchor=an,
                                 tries=[(0, 0, an), (0, -21, an), (0, 21, an)])
        s.append(f'<text x="{lx:.1f}" y="{ly:.1f}" font-family="Cormorant Garamond" '
                 f'font-weight="600" font-size="20" fill="{C["ink"]}" text-anchor="{an}">{n}</text>')
        if order_num.get(n):
            s.append(f'<text x="{x:.1f}" y="{y+3.4:.1f}" font-family="IBM Plex Mono" '
                     f'font-size="8" fill="{C["paper"]}" text-anchor="middle">{order_num[n]}</text>')

    # --- title block ---
    s.append(f'<text x="94" y="86" font-family="IBM Plex Mono" font-size="10" '
             f'letter-spacing="4.5" fill="{C["soft"]}">A DECISION MANUAL — THE FIRST AMERICAN TRIP</text>')
    s.append(f'<text x="92" y="162" font-family="Cormorant Garamond" font-weight="600" '
             f'font-size="84" fill="{C["ink"]}">Greece, in Order.</text>')
    s.append(f'<text x="95" y="202" font-family="Cormorant Garamond" font-style="italic" '
             f'font-size="23" fill="{C["accent"]}">What a first island trip really costs —</text>')
    s.append(f'<text x="95" y="229" font-family="Cormorant Garamond" font-style="italic" '
             f'font-size="23" fill="{C["accent"]}">and the wrong turn that costs the whole thing.</text>')
    s.append(f'<line x1="94" y1="245" x2="724" y2="245" stroke="{C["line"]}" stroke-width="1"/>')

    # --- footer ---
    s.append(f'<text x="94" y="892" font-family="IBM Plex Mono" font-size="9" '
             f'letter-spacing="1.5" fill="{C["muted"]}">The Cyclades, drawn to scale from real sea '
             f'distances.</text>')
    s.append(f'<text x="94" y="910" font-family="IBM Plex Mono" font-size="9" '
             f'letter-spacing="1.5" fill="{C["muted"]}">The wind runs north; so does the risk to your '
             f'flight home.</text>')
    s.append(f'<text x="94" y="978" font-family="Cormorant Garamond" font-style="italic" '
             f'font-size="17" fill="{C["muted"]}">greeceforamericans · Come Up For Air</text>')
    s.append(f'<text x="724" y="978" font-family="IBM Plex Mono" font-size="9" '
             f'letter-spacing="1" fill="{C["soft"]}" text-anchor="end">EDITION ONE</text>')
    s.append('</svg>')
    return "".join(s)

# ===================================================================
# FIG — the asymmetry: same trip, two orders. One costs an afternoon,
# the other costs the flight. This is the free hook, drawn.
# ===================================================================
def FIG_ASYMMETRY():
    W, H = 660, 300
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<rect width="{W}" height="{H}" fill="{C["paper"]}"/>')

    def strip(y, order, tag, tagcol, note):
        x0 = 96; step = 118
        # baseline
        s.append(f'<line x1="{x0}" y1="{y}" x2="{x0+step*3+20}" y2="{y}" '
                 f'stroke="{C["line"]}" stroke-width="1"/>')
        for i, n in enumerate(order):
            x = x0 + i * step
            last = (i == len(order) - 1)
            fill = C["accent"] if last and n == "Santorini" else C["ink"]
            s.append(f'<circle cx="{x}" cy="{y}" r="6" fill="{fill}"/>')
            s.append(f'<text x="{x}" y="{y-13}" font-family="Cormorant Garamond" '
                     f'font-weight="600" font-size="15" fill="{C["ink"]}" text-anchor="middle">{n}</text>')
            if i < len(order) - 1:
                nx = x0 + (i + 1) * step
                b = order[i + 1]
                d = km(n, b) if (n in GEO and b in GEO) else 0
                s.append(f'<text x="{(x+nx)/2:.0f}" y="{y+16}" font-family="IBM Plex Mono" '
                         f'font-size="8.5" fill="{C["muted"]}" text-anchor="middle">{d:.0f} km</text>')
        # the last leg + flight
        xf = x0 + 3 * step
        s.append(f'<text x="{xf+18}" y="{y+4}" font-family="IBM Plex Mono" font-size="9" '
                 f'fill="{tagcol}">{tag}</text>')
        s.append(f'<text x="{x0}" y="{y-34}" font-family="IBM Plex Mono" font-size="8" '
                 f'letter-spacing="1.6" fill="{C["soft"]}">{note}</text>')

    strip(96, ["Piraeus", "Santorini", "Naxos", "Piraeus"], "→ afternoon lost", C["gilt"],
          "SANTORINI FIRST — the fast-boat leg sits mid-trip; a cancel costs a beach day")
    strip(232, ["Piraeus", "Naxos", "Santorini", "Piraeus"], "→ flight at risk", C["accent"],
          "SANTORINI LAST — the fast-boat leg sits against your flight home")
    s.append(f'<line x1="30" y1="164" x2="{W-30}" y2="164" stroke="{C["line_soft"]}" '
             f'stroke-width="1" stroke-dasharray="2 5"/>')
    s.append('</svg>')
    return "".join(s)

# ===================================================================
# FIG — Cyclades locator: real distances from Piraeus, the hop legs.
# ===================================================================
def FIG_CYCLADES():
    W, H = 660, 340
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<rect width="{W}" height="{H}" fill="{C["paper"]}"/>')
    names = ["Piraeus", "Mykonos", "Delos", "Naxos", "Paros", "Ios", "Santorini", "Milos"]
    xy = _proj(names, 20, 16, W - 40, H - 40, pad=44)
    P = {n: xy(n) for n in names}
    # sea shading
    s.append(f'<rect x="20" y="16" width="{W-40}" height="{H-40}" fill="{C["water"]}" opacity="0.28"/>')
    # hop legs among the core islands
    legs = [("Mykonos", "Naxos"), ("Naxos", "Paros"), ("Naxos", "Santorini"),
            ("Paros", "Santorini"), ("Santorini", "Ios"), ("Ios", "Naxos")]
    for a, b in legs:
        (x1, y1), (x2, y2) = P[a], P[b]
        s.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                 f'stroke="{C["soft"]}" stroke-width="0.9" stroke-dasharray="2 4" opacity="0.8"/>')
    # arcs from Piraeus to each (the sea distance is the point)
    for isl in ["Mykonos", "Naxos", "Paros", "Santorini", "Milos"]:
        (x1, y1), (x2, y2) = P["Piraeus"], P[isl]
        s.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                 f'stroke="{C["line"]}" stroke-width="0.8" opacity="0.7"/>')
    boxes = _Boxes()
    for n in names:
        x, y = P[n]
        big = n in ("Piraeus", "Santorini")
        r = 6.5 if big else (3.5 if n == "Delos" else 5)
        s.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{r}" fill="{C["accent"] if big else C["ink"]}"/>')
        lab = n
        fs = 13 if not big else 14
        lx, ly, an = boxes.place(x + 9, y + 4, lab, fs,
                                 anchor="start" if x < W * 0.62 else "end")
        s.append(f'<text x="{lx:.1f}" y="{ly:.1f}" font-family="Cormorant Garamond" '
                 f'font-weight="600" font-size="{fs}" fill="{C["ink"]}" text-anchor="{an}">{lab}</text>')
    # legend: distance from Piraeus for the anchors
    yb = H - 8
    s.append(f'<text x="24" y="30" font-family="IBM Plex Mono" font-size="8" '
             f'letter-spacing="2" fill="{C["soft"]}">SEA DISTANCE FROM PIRAEUS</text>')
    dd = "   ".join(f'{i}·{km("Piraeus", i):.0f}km' for i in ["Paros", "Naxos", "Santorini"])
    s.append(f'<text x="24" y="{yb}" font-family="IBM Plex Mono" font-size="8.5" '
             f'fill="{C["muted"]}">{dd}</text>')
    s.append('</svg>')
    return "".join(s)

# ===================================================================
# FIG — Crete drive-time: distance, not opening hours, is the limit.
# ===================================================================
def FIG_CRETE():
    W, H = 660, 250
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<rect width="{W}" height="{H}" fill="{C["paper"]}"/>')
    # schematic island spine W->E with the two hubs and drive time between
    y = 130
    x0, x1 = 80, W - 80
    s.append(f'<line x1="{x0}" y1="{y}" x2="{x1}" y2="{y}" stroke="{C["stone"]}" '
             f'stroke-width="16" stroke-linecap="round"/>')
    s.append(f'<line x1="{x0}" y1="{y}" x2="{x1}" y2="{y}" stroke="{C["line"]}" '
             f'stroke-width="1"/>')
    pts = [("Chania", x0, "west base"), ("Rethymno", x0 + (x1 - x0) * 0.38, ""),
           ("Heraklion", x0 + (x1 - x0) * 0.66, "central base"),
           ("Agios Nikolaos", x1, "east")]
    for name, x, tag in pts:
        s.append(f'<circle cx="{x:.0f}" cy="{y}" r="6.5" fill="{C["accent"] if tag.endswith("base") else C["ink"]}"/>')
        s.append(f'<text x="{x:.0f}" y="{y-16}" font-family="Cormorant Garamond" '
                 f'font-weight="600" font-size="15" fill="{C["ink"]}" text-anchor="middle">{name}</text>')
        if tag:
            s.append(f'<text x="{x:.0f}" y="{y+26}" font-family="IBM Plex Mono" font-size="8" '
                     f'letter-spacing="1" fill="{C["muted"]}" text-anchor="middle">{tag}</text>')
    # the drive-time bracket Chania<->Heraklion (~2h per corpus)
    bx0, bx1 = x0, x0 + (x1 - x0) * 0.66
    by = y - 52
    s.append(f'<path d="M{bx0},{by+8} L{bx0},{by} L{bx1},{by} L{bx1},{by+8}" fill="none" '
             f'stroke="{C["gilt"]}" stroke-width="1.4"/>')
    s.append(f'<text x="{(bx0+bx1)/2:.0f}" y="{by-6}" font-family="IBM Plex Mono" '
             f'font-size="10" fill="{C["gilt"]}" text-anchor="middle">~2 hours by road</text>')
    # west-end lagoons note
    s.append(f'<text x="{x0}" y="{y+58}" font-family="IBM Plex Mono" font-size="8" '
             f'letter-spacing="1" fill="{C["soft"]}">Elafonisi / Balos — day trips from a WEST base only</text>')
    s.append(f'<text x="24" y="30" font-family="IBM Plex Mono" font-size="8" '
             f'letter-spacing="2" fill="{C["soft"]}">CRETE, END TO END — ~160 MILES</text>')
    s.append('</svg>')
    return "".join(s)

# ===================================================================
# FIG — ferry vs fly: the time ledger on the long legs.
# ===================================================================
def FIG_FERRYFLY():
    W, H = 660, 258
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<rect width="{W}" height="{H}" fill="{C["paper"]}"/>')
    # horizontal hours axis
    ax0, ax1 = 150, W - 40
    maxh = 9.0
    def hx(h): return ax0 + (h / maxh) * (ax1 - ax0)
    rows = [
        ("Athens–Santorini", 5.0, 8.0, 0.75),   # fast, conv, flight (hrs)
        ("Athens–Naxos", 4.5, 5.5, 0.75),
        ("Athens–Mykonos", 3.5, 5.0, 0.70),
        ("Athens–Crete (HER)", None, 9.0, 1.0),  # ferry overnight only
    ]
    y = 58; dy = 46
    # axis ticks
    for h in range(0, 10, 2):
        x = hx(h)
        s.append(f'<line x1="{x:.0f}" y1="48" x2="{x:.0f}" y2="{y+dy*len(rows)-24}" '
                 f'stroke="{C["line_soft"]}" stroke-width="0.8"/>')
        s.append(f'<text x="{x:.0f}" y="40" font-family="IBM Plex Mono" font-size="8" '
                 f'fill="{C["soft"]}" text-anchor="middle">{h}h</text>')
    for label, fast, conv, flight in rows:
        s.append(f'<text x="24" y="{y+4}" font-family="Cormorant Garamond" font-weight="600" '
                 f'font-size="13.5" fill="{C["ink"]}">{label}</text>')
        # conventional bar (stone)
        s.append(f'<rect x="{ax0}" y="{y-9}" width="{hx(conv)-ax0:.0f}" height="9" '
                 f'fill="{C["stone"]}"/>')
        s.append(f'<text x="{hx(conv)+5:.0f}" y="{y-1:.0f}" font-family="IBM Plex Mono" '
                 f'font-size="8" fill="{C["muted"]}">{conv:.0f}h boat</text>')
        # fast bar (accent) overlaid
        if fast:
            s.append(f'<rect x="{ax0}" y="{y-9}" width="{hx(fast)-ax0:.0f}" height="9" '
                     f'fill="{C["soft"]}"/>')
        # flight bar (gilt) thin
        s.append(f'<rect x="{ax0}" y="{y+3}" width="{hx(flight)-ax0:.0f}" height="6" '
                 f'fill="{C["gilt"]}"/>')
        s.append(f'<text x="{hx(flight)+5:.0f}" y="{y+9:.0f}" font-family="IBM Plex Mono" '
                 f'font-size="8" fill="{C["gilt"]}">{int(flight*60)}min fly</text>')
        y += dy
    s.append(f'<text x="24" y="24" font-family="IBM Plex Mono" font-size="8" '
             f'letter-spacing="2" fill="{C["soft"]}">DOOR TO DOCK — TIME BY MODE</text>')
    s.append('</svg>')
    return "".join(s)

# ===================================================================
# FIG — the season strip: when the islands are open, and the meltemi band.
# ===================================================================
def FIG_SEASON():
    W, H = 660, 250
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<rect width="{W}" height="{H}" fill="{C["paper"]}"/>')
    months = ["J","F","M","A","M","J","J","A","S","O","N","D"]
    x0 = 120; cw = (W - x0 - 30) / 12; ytop = 60
    def band(y, label, cells, col):
        s.append(f'<text x="24" y="{y+12}" font-family="IBM Plex Mono" font-size="8.5" '
                 f'letter-spacing="1" fill="{C["muted"]}">{label}</text>')
        for i in range(12):
            x = x0 + i * cw
            on = cells[i]
            fill = col if on == 2 else (C["stone"] if on == 1 else C["paper"])
            s.append(f'<rect x="{x:.1f}" y="{y}" width="{cw-2:.1f}" height="18" fill="{fill}" '
                     f'stroke="{C["line_soft"]}" stroke-width="0.6"/>')
    # header months
    for i, m in enumerate(months):
        x = x0 + i * cw + (cw - 2) / 2
        s.append(f'<text x="{x:.1f}" y="{ytop-6}" font-family="IBM Plex Mono" font-size="8" '
                 f'fill="{C["soft"]}" text-anchor="middle">{m}</text>')
    #                J F M A M J J A S O N D
    band(ytop,      "Cyclades open", [0,0,1,1,2,2,2,2,2,2,1,0], C["accent"])
    band(ytop+30,   "shoulder value", [0,0,0,0,2,2,1,1,2,2,0,0], C["gilt"])
    band(ytop+60,   "meltemi risk",  [0,0,0,0,0,1,2,2,1,0,0,0], C["deep"])
    band(ytop+90,   "peak crowds",   [0,0,0,0,0,1,2,2,1,0,0,0], C["soft"])
    # legend
    ly = ytop + 130
    s.append(f'<rect x="120" y="{ly}" width="14" height="10" fill="{C["accent"]}"/>')
    s.append(f'<text x="140" y="{ly+9}" font-family="IBM Plex Mono" font-size="8" fill="{C["muted"]}">strong</text>')
    s.append(f'<rect x="210" y="{ly}" width="14" height="10" fill="{C["stone"]}"/>')
    s.append(f'<text x="230" y="{ly+9}" font-family="IBM Plex Mono" font-size="8" fill="{C["muted"]}">partial / shoulder edge</text>')
    s.append(f'<text x="24" y="30" font-family="IBM Plex Mono" font-size="8" '
             f'letter-spacing="2" fill="{C["soft"]}">THE YEAR, IN BANDS</text>')
    s.append('</svg>')
    return "".join(s)

# ---- FIG_ARRIVAL: airport → city → port, real times (Day Zero) ----
def FIG_ARRIVAL():
    W, H = 660, 250
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<text x="24" y="26" font-family="IBM Plex Mono" font-size="8" '
             f'letter-spacing="2" fill="{C["soft"]}">ARRIVAL — AIRPORT TO CITY OR PORT</text>')
    # three nodes across
    ax, cx, px = 120, 355, 560
    ny = 96
    nodes = [(ax, "ATH airport", C["deep"]), (cx, "Central Athens", C["accent"]),
             (px, "Piraeus port", C["accent"])]
    for x, lab, col in nodes:
        s.append(f'<circle cx="{x}" cy="{ny}" r="9" fill="{col}"/>')
        s.append(f'<text x="{x}" y="{ny-20}" font-family="Cormorant Garamond" font-weight="600" '
                 f'font-size="17" fill="{C["ink"]}" text-anchor="middle">{lab}</text>')
    # airport -> city : three modes stacked as labelled lines
    def leg(x1, x2, y, txt, col, dash=None):
        d = f' stroke-dasharray="{dash}"' if dash else ""
        s.append(f'<line x1="{x1+11}" y1="{y}" x2="{x2-11}" y2="{y}" stroke="{col}" '
                 f'stroke-width="2"{d}/>')
        s.append(f'<text x="{(x1+x2)/2:.0f}" y="{y-6}" font-family="IBM Plex Mono" '
                 f'font-size="8.5" fill="{C["deep"]}" text-anchor="middle">{txt}</text>')
    # metro line (the recommended one) solid; taxi + bus as annotations below
    leg(ax, cx, ny, "Metro L3 · ~40 min · flat fare", C["accent"])
    s.append(f'<text x="{(ax+cx)/2:.0f}" y="{ny+18}" font-family="IBM Plex Mono" font-size="8" '
             f'fill="{C["muted"]}" text-anchor="middle">taxi 30–45 min · X95 bus 24h, slower</text>')
    # city -> port
    leg(cx, px, ny, "Metro · ~20–30 min", C["accent"])
    # the arrival-day rule, boxed low
    by = 168
    s.append(f'<rect x="120" y="{by}" width="440" height="54" rx="3" fill="{C["zone"]}" '
             f'stroke="{C["line"]}"/>')
    s.append(f'<text x="134" y="{by+21}" font-family="Cormorant Garamond" font-style="italic" '
             f'font-size="14" fill="{C["ink"]}">The rule: don\'t book an island ferry for your arrival day.</text>')
    s.append(f'<text x="134" y="{by+40}" font-family="Cormorant Garamond" font-style="italic" '
             f'font-size="14" fill="{C["muted"]}">Overnight in Athens first — jet lag plus a missed boat is a bad first act.</text>')
    s.append('</svg>')
    return "".join(s)

# ---- FIG_DECISIONTREE: which islands fit you (Decision 02) ----
def FIG_DECISIONTREE():
    W, H = 660, 300
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<text x="24" y="26" font-family="IBM Plex Mono" font-size="8" '
             f'letter-spacing="2" fill="{C["soft"]}">WHICH ISLANDS — A FORK, NOT A RANKING</text>')

    def node(x, y, w, txt, fill, ink=None, fs=13):
        ink = ink or C["ink"]
        s.append(f'<rect x="{x-w/2:.0f}" y="{y-15:.0f}" width="{w}" height="30" rx="3" '
                 f'fill="{fill}" stroke="{C["line"]}"/>')
        s.append(f'<text x="{x}" y="{y+5:.0f}" font-family="Cormorant Garamond" font-weight="600" '
                 f'font-size="{fs}" fill="{ink}" text-anchor="middle">{txt}</text>')

    def link(x1, y1, x2, y2, lab=None):
        s.append(f'<path d="M {x1} {y1} C {x1} {(y1+y2)/2:.0f}, {x2} {(y1+y2)/2:.0f}, {x2} {y2}" '
                 f'fill="none" stroke="{C["soft"]}" stroke-width="1.4"/>')
        if lab:
            s.append(f'<text x="{(x1+x2)/2:.0f}" y="{(y1+y2)/2:.0f}" font-family="IBM Plex Mono" '
                     f'font-size="8" fill="{C["deep"]}" text-anchor="middle" '
                     f'style="paint-order:stroke;stroke:{C["paper"]};stroke-width:3px">{lab}</text>')

    # root
    node(330, 50, 210, "One famous + one value", C["accent"], C["paper"])
    # two mid questions
    node(180, 130, 200, "Value island: which?", C["zone"])
    node(500, 130, 210, "Famous island: the finale", C["zone"])
    link(330, 65, 180, 115, "the rest")
    link(330, 65, 500, 115, "last")
    # value leaves
    node(110, 215, 150, "Naxos", C["paper"])
    node(270, 215, 150, "Paros", C["paper"])
    link(180, 145, 110, 200, "beaches / space")
    link(180, 145, 270, 200, "pace / links")
    # famous leaf
    node(500, 215, 160, "Santorini", C["paper"])
    link(500, 145, 500, 200)
    # gloss line
    node(110, 270, 150, "best beaches, value", C["stone"], C["muted"], 11)
    node(270, 270, 150, "relaxed, connected", C["stone"], C["muted"], 11)
    node(500, 270, 160, "reached last, w/ buffer", C["stone"], C["muted"], 11)
    s.append('</svg>')
    return "".join(s)


# ---- FIG_SEVERITY: the failure modes, ranked by what they cost (Failure Modes) ----
def FIG_SEVERITY():
    W, H = 660, 300
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<text x="24" y="24" font-family="IBM Plex Mono" font-size="8" '
             f'letter-spacing="2" fill="{C["soft"]}">MISTAKES, RANKED BY WHAT THEY COST</text>')
    tiers = [
        ("Costs the trip / a flight home", 1.00, C["deep"],
         "ferry on flight day · assuming fast boats run · no buffer · Crete as a hop"),
        ("Costs a day (or several)", 0.66, C["accent"],
         "five islands a week · nightly hotel-hopping · ferrying long legs · arrival-day boat"),
        ("Costs money", 0.42, C["gilt"],
         "USD at the reader · Euronet ATMs · US-style tips · two famous islands · eating on the view"),
        ("Costs comfort / the experience", 0.24, C["soft"],
         "fast boat when queasy · Acropolis at midday · the crowded sunset · car on Santorini"),
    ]
    x0, top, rowh, maxw = 40, 44, 58, 420
    for i, (lab, frac, col, egs) in enumerate(tiers):
        y = top + i * rowh
        s.append(f'<rect x="{x0}" y="{y}" width="{maxw*frac:.0f}" height="26" fill="{col}"/>')
        s.append(f'<text x="{x0+6}" y="{y+17:.0f}" font-family="Cormorant Garamond" '
                 f'font-weight="600" font-size="14" fill="{C["paper"]}">{lab}</text>')
        s.append(f'<text x="{x0}" y="{y+43:.0f}" font-family="IBM Plex Mono" font-size="7.6" '
                 f'fill="{C["muted"]}">{egs}</text>')
    # severity axis note
    s.append(f'<text x="{x0}" y="{top+4*rowh+6:.0f}" font-family="Cormorant Garamond" '
             f'font-style="italic" font-size="13" fill="{C["ink"]}">Bar length = how much a single '
             f'mistake in that tier can cost you. Fix the top tier first.</text>')
    s.append('</svg>')
    return "".join(s)

# ---- FIG_SHAPES: the trip lengths as structures (The Plan) ----
def FIG_SHAPES():
    W, H = 660, 300
    s = [f'<svg viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">']
    s.append(f'<text x="24" y="24" font-family="IBM Plex Mono" font-size="8" '
             f'letter-spacing="2" fill="{C["soft"]}">THE SHAPES THAT SURVIVE THE FERRY NETWORK</text>')
    # each row: a trip, drawn as a chain of stops sized by nights, ending in "fly home"
    trips = [
        ("5 days", [("Athens", 2, C["stone"]), ("1 island", 3, C["accent"])]),
        ("7 days", [("Athens", 2, C["stone"]), ("value isl.", 2, C["gilt"]), ("Santorini", 3, C["accent"])]),
        ("10 days", [("Athens", 2, C["stone"]), ("value isl.", 3, C["gilt"]), ("Santorini", 3, C["accent"]), ("+ hop", 2, C["water"])]),
        ("14 days", [("Athens", 2, C["stone"]), ("value isl.", 3, C["gilt"]), ("Santorini", 4, C["accent"]), ("Crete (fly)", 4, C["deep"])]),
    ]
    x0, top, rowh = 96, 52, 60
    unit = 30  # px per night
    for i, (lab, stops) in enumerate(trips):
        y = top + i * rowh
        s.append(f'<text x="{x0-12}" y="{y+18:.0f}" font-family="IBM Plex Mono" font-size="9.5" '
                 f'fill="{C["ink"]}" text-anchor="end">{lab}</text>')
        x = x0
        for j, (nm, nights, col) in enumerate(stops):
            w = nights * unit
            s.append(f'<rect x="{x}" y="{y}" width="{w}" height="28" rx="2" fill="{col}"/>')
            s.append(f'<text x="{x+w/2:.0f}" y="{y+13:.0f}" font-family="Cormorant Garamond" '
                     f'font-weight="600" font-size="11" fill="{C["paper"]}" text-anchor="middle">{nm}</text>')
            s.append(f'<text x="{x+w/2:.0f}" y="{y+24:.0f}" font-family="IBM Plex Mono" '
                     f'font-size="7" fill="{C["paper"]}" text-anchor="middle">{nights}n</text>')
            x += w + 4
        # fly-home tail
        s.append(f'<line x1="{x}" y1="{y+14}" x2="{x+34}" y2="{y+14}" stroke="{C["gilt"]}" '
                 f'stroke-width="1.6" stroke-dasharray="3 3"/>')
        s.append(f'<text x="{x+38}" y="{y+18:.0f}" font-family="IBM Plex Mono" font-size="8" '
                 f'fill="{C["muted"]}">fly ATH</text>')
    s.append(f'<text x="{x0-12}" y="{top+4*rowh+6:.0f}" font-family="Cormorant Garamond" '
             f'font-style="italic" font-size="12.5" fill="{C["muted"]}">Every shape ends by flying back '
             f'to Athens — the leg the wind can\'t cancel.</text>')
    s.append('</svg>')
    return "".join(s)


# ---- geometry self-check (d-draw.md: verify, don't eyeball) ----
def _selfcheck():
    # thesis check: Santorini must be the furthest core Cyclade from both Piraeus and Mykonos
    dP = {i: km("Piraeus", i) for i in ["Paros","Naxos","Mykonos","Ios","Santorini"]}
    assert max(dP, key=dP.get) == "Santorini", dP
    dM = {i: km("Mykonos", i) for i in ["Naxos","Paros","Santorini"]}
    assert max(dM, key=dM.get) == "Santorini", dM
    return dP, dM

if __name__ == "__main__":
    print("geo self-check:", _selfcheck())
    for fn in [COVER, FIG_ASYMMETRY, FIG_CYCLADES, FIG_CRETE, FIG_FERRYFLY, FIG_SEASON,
               FIG_ARRIVAL, FIG_DECISIONTREE, FIG_SEVERITY, FIG_SHAPES]:
        svg = fn()
        assert svg.startswith("<svg"), fn.__name__
        print(f"{fn.__name__:16s} ok  {len(svg)} chars")
