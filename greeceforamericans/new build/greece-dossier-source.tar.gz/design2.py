# design2.py — THE CSS LIVES HERE (bug log #1). Nothing style-related in build3.py.
import pathlib

FONTS_CSS = pathlib.Path(__file__).with_name("fonts").joinpath("fonts.css").read_text()

# --- Come Up For Air, translated for print (see greeceforamericans.json) ---
TOK = dict(
    paper="#F3ECDC", ink="#172630", accent="#17627F", gilt="#C6A24E",
    muted="#5E6B72", soft="#8B9AA1", line="#D7CBAE", line_soft="#E4DAC1",
    zone="#E6DCC0", stone="#DFD4B4", deep="#0E3E52", water="#CDDBDD",
)

_CSS_TMPL = """
*{margin:0;padding:0;box-sizing:border-box}
:root{
 --paper:@paper@; --ink:@ink@; --accent:@accent@; --gilt:@gilt@;
 --muted:@muted@; --soft:@soft@; --line:@line@; --line-soft:@line_soft@;
 --zone:@zone@; --stone:@stone@; --deep:@deep@; --water:@water@;
 --display:'Cormorant Garamond'; --body:'Sorts Mill Goudy'; --mono:'IBM Plex Mono';
}
html{-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{background:var(--paper);color:var(--ink);font-family:var(--body);
     font-size:13.4px;line-height:1.68;font-feature-settings:"liga","onum","kern"}

/* ---------- PAGE ---------- */
.page{width:8.5in;height:11in;padding:0.85in;position:relative;
      background:var(--paper);color:var(--ink);overflow:hidden}
.page.flowpage{padding:0}          /* flow sets its own padding */

/* ---------- COVER ---------- */
.cover{position:absolute;top:0;left:0;width:8.5in;height:11in;overflow:hidden;
       background:var(--paper)}
.cover svg{position:absolute;top:0;left:0;width:8.5in;height:11in;display:block}

/* ---------- TYPE SCALE ---------- */
h1.t{font-family:var(--display);font-weight:600;font-size:44px;line-height:1.06;
     letter-spacing:.004em;margin-bottom:19px}
h1.t .sub{display:block;font-size:17px;font-weight:400;font-style:italic;
     color:var(--muted);letter-spacing:.01em;margin-top:9px}
.eyebrow{font-family:var(--mono);font-size:8px;letter-spacing:.26em;
     text-transform:uppercase;color:var(--soft);margin-bottom:19px}
.standfirst{font-family:var(--display);font-size:19.5px;font-style:italic;
     line-height:1.4;color:var(--ink);margin-bottom:22px;padding-bottom:20px;
     border-bottom:1px solid var(--line-soft)}
p{margin:0 0 11px;text-align:justify;hyphens:auto;-webkit-hyphens:auto}
p.nojust{text-align:left;hyphens:none}
.lead{margin-bottom:12px}
.dropcap::first-letter{font-family:var(--display);font-weight:600;float:left;
     font-size:60px;line-height:44px;padding:6px 10px 0 0;color:var(--accent)}
strong{font-weight:400;color:var(--accent)}
em{font-style:italic}
h2.sec{font-family:var(--display);font-weight:600;font-size:25px;line-height:1.12;
     margin:0 0 10px;color:var(--ink)}
h3.sub{font-family:var(--mono);font-size:9.5px;letter-spacing:.2em;
     text-transform:uppercase;color:var(--accent);margin:0 0 8px}

/* ---------- FLOW ---------- */
.flow{padding:0.66in 0.82in}
.flow .dec + .dec{margin-top:25px}
.flow h1, .flow .dnum, .flow .standfirst, .flow h2.sec, .flow h3.sub{break-after:avoid}
.flow table, .flow figure, .flow .forlist, .flow .note, .flow .aside,
.flow .pull, .flow .verdict{break-inside:avoid}
.flow .verdict + .forlist{break-before:avoid}
.flow p{orphans:3;widows:3}
.dnum{font-family:var(--mono);font-size:8px;letter-spacing:.24em;color:var(--accent);
     text-transform:uppercase;margin-bottom:7px;display:flex;
     justify-content:space-between;align-items:baseline}
.dnum .rt{color:var(--soft)}
.dtitle{font-family:var(--display);font-weight:600;font-size:27px;line-height:1.08;
     margin-bottom:11px}

/* ---------- LEDGER ---------- */
.led{width:100%;border-collapse:collapse;margin:6px 0 4px;font-size:12px}
.led-h{font-family:var(--mono);font-size:8px;letter-spacing:.18em;text-transform:uppercase;
     color:var(--soft);display:flex;justify-content:space-between;align-items:baseline;
     margin-top:6px;padding-bottom:8px;border-bottom:1px solid var(--line)}
.led-h .cols{color:var(--muted);letter-spacing:.12em}
.led td{padding:7px 2px;border-bottom:1px solid var(--line-soft);line-height:1.46;
     vertical-align:top}
.led td.num{text-align:right;font-family:var(--mono);font-size:10.5px;color:var(--ink);
     white-space:nowrap;padding-left:16px;width:1%}
.led tr:last-child td{border-bottom:none}
.led .opt{color:var(--ink)}
.led .gloss{color:var(--muted);font-size:11px}

/* ---------- VERDICT ---------- */
.verdict{background:var(--zone);border-left:2.5px solid var(--accent);
     padding:13px 16px 14px;margin:15px 0 0;font-size:12.8px;line-height:1.6}
.verdict .lab{font-family:var(--mono);font-size:8px;letter-spacing:.2em;
     text-transform:uppercase;color:var(--accent);display:block;margin-bottom:6px}
.verdict strong{color:var(--accent)}
.forlist{list-style:none;margin:11px 0 0;font-size:11.8px;line-height:1.5}
.forlist li{padding:5px 0 5px 18px;position:relative;border-bottom:1px solid var(--line-soft)}
.forlist li:last-child{border-bottom:none}
.forlist li::before{content:"→";position:absolute;left:0;color:var(--gilt);
     font-family:var(--mono);font-size:11px}
.forlist li b{color:var(--accent);font-weight:400}

/* ---------- MARKS ---------- */
.mk{font-family:var(--mono);font-size:9px;letter-spacing:.02em;white-space:nowrap}
.mk.est{color:var(--accent)}
.mk.off{color:var(--gilt)}
.mk.sur{color:var(--muted)}
.mk.vol{color:var(--soft)}

/* ---------- NOTES / ASIDES / PULLS ---------- */
.note{font-size:11px;line-height:1.66;color:var(--muted);margin:14px 0 0;
     padding-top:9px;border-top:1px solid var(--line-soft)}
.note b{color:var(--accent);font-weight:400}
.aside{background:var(--stone);padding:13px 15px;margin:20px 0;font-size:11.3px;
     line-height:1.62;border:1px solid var(--line)}
.aside .h{font-family:var(--mono);font-size:8px;letter-spacing:.2em;text-transform:uppercase;
     color:var(--accent);margin-bottom:7px}
.pull{font-family:var(--display);font-style:italic;font-size:20px;line-height:1.34;
     color:var(--accent);margin:20px 0;padding:2px 0 2px 18px;
     border-left:2px solid var(--gilt)}

/* ---------- FIGURES ---------- */
.map,.photo{margin:8px 0 22px}
.map svg,.photo img{width:100%;display:block;border:1px solid var(--line-soft)}
.photo img{height:2.35in;object-fit:cover}
.map figcaption,.photo figcaption{margin-top:10px;padding-top:8px;
     border-top:1px solid var(--line-soft);font-size:7.5px;line-height:1.6;
     font-family:var(--mono);letter-spacing:.02em;color:var(--muted);
     text-transform:none}
.fign{color:var(--accent);letter-spacing:.16em;font-weight:500}

/* ---------- LISTS in prose ---------- */
ul.tick{list-style:none;margin:10px 0;font-size:12.4px;line-height:1.55}
ul.tick li{padding:5px 0 5px 20px;position:relative;border-bottom:1px solid var(--line-soft)}
ul.tick li:last-child{border-bottom:none}
ul.tick li::before{content:"—";position:absolute;left:0;color:var(--gilt)}
ul.tick li b{color:var(--accent);font-weight:400}

/* ---------- CHAPTER OPENER RULE ---------- */
.opener{border-top:2px solid var(--ink);padding-top:14px;margin-top:2px}

/* ---------- TOC ---------- */
.toc{width:100%;border-collapse:collapse;font-size:12.5px;margin-top:6px}
.toc td{padding:8px 0;border-bottom:1px solid var(--line-soft);vertical-align:baseline}
.toc td.pg{text-align:right;font-family:var(--mono);font-size:10px;color:var(--soft);
     width:1%;white-space:nowrap;padding-left:20px}
.toc .grp{font-family:var(--mono);font-size:8px;letter-spacing:.22em;text-transform:uppercase;
     color:var(--accent);padding-top:18px}
.toc .ti{color:var(--ink)}
.toc .gl{color:var(--muted);font-size:11px}

/* ---------- FIELD SHEET ---------- */
.fs{width:100%;border-collapse:collapse;font-size:11.5px;margin-top:6px}
.fs td,.fs th{padding:7px 2px;border-bottom:1px solid var(--line-soft);text-align:left;
     vertical-align:top;line-height:1.5}
.fs th{font-family:var(--mono);font-size:8px;letter-spacing:.14em;text-transform:uppercase;
     color:var(--soft);border-bottom:1px solid var(--line)}
.fs td.v{font-family:var(--mono);font-size:10px;color:var(--ink);white-space:nowrap}
.fs .src{color:var(--muted);font-size:10px}

/* ---------- HOW-TO-READ marks table ---------- */
.marks{width:100%;border-collapse:collapse;font-size:12px;margin-top:4px}
.marks td{padding:9px 4px;border-bottom:1px solid var(--line-soft);vertical-align:top;
     line-height:1.5}
.marks td.m{width:1%;white-space:nowrap;padding-right:14px}

/* ---------- WALLET CARD ---------- */
.wallet{border:1.5px solid var(--ink);padding:16px 18px;margin-top:8px;background:var(--zone)}
.wallet .wh{font-family:var(--mono);font-size:8px;letter-spacing:.2em;text-transform:uppercase;
     color:var(--accent);margin-bottom:10px;display:flex;justify-content:space-between}
.wallet dl{display:grid;grid-template-columns:auto 1fr;gap:6px 14px;font-size:11.3px;
     line-height:1.4}
.wallet dt{font-family:var(--mono);font-size:9px;color:var(--muted);letter-spacing:.04em;
     white-space:nowrap}
.wallet dd{color:var(--ink)}
.wallet dd b{color:var(--accent);font-weight:400}

/* ---------- BACK MATTER refusals ---------- */
.refuse{margin-top:6px}
.refuse .r{padding:11px 0;border-bottom:1px solid var(--line-soft)}
.refuse .r:last-child{border-bottom:none}
.refuse .rk{font-family:var(--display);font-style:italic;font-size:16px;color:var(--accent);
     margin-bottom:4px}
.refuse .rv{font-size:12px;line-height:1.55;color:var(--ink)}

/* ---------- RUNNING FURNITURE (baked into fixed pages; flow uses template) ---------- */
.folio{position:absolute;left:0;right:0;bottom:0.5in;text-align:center;
     font-family:var(--mono);font-size:8px;letter-spacing:.2em;color:var(--soft)}
.runhead{position:absolute;top:0.5in;left:0.85in;right:0.85in;display:flex;
     justify-content:space-between;font-family:var(--mono);font-size:7.5px;
     letter-spacing:.2em;text-transform:uppercase;color:var(--soft)}
"""

def _apply(tmpl, tok):
    for k, v in tok.items():
        tmpl = tmpl.replace("@" + k + "@", v)
    return tmpl

PRINT = """
@page { size: 8.5in 11in; margin: 0; }
.coverpage{ width:8.5in; height:11in; position:relative; overflow:hidden;
            break-after:page; page-break-after:always; }
.cover{ position:absolute; top:0; left:0; width:8.5in; height:11in; }
.cover svg{ position:absolute; top:0; left:0; width:8.5in; height:11in; display:block; }
/* the flow root is a plain flowing block; the print engine paginates it.
   symmetric padding clears the running footer template band (layout.md).
   Set to sit near Rome's comfortable 71-82% fill, not a cramped 92%. */
.flowroot{ padding:0.92in 0.92in 0.8in; }
.flowroot, .flowroot p, .flowroot li{ font-size:13.7px; line-height:1.82; }
.flowroot p{ margin-bottom:11px; }
.flowroot .dec + .dec{ margin-top:34px; }
.flowroot .led td{ padding:9px 2px; }
.flowroot figure{ margin:20px 0; }
.flowroot .tick li{ margin-bottom:8px; }
.flowroot .fs td, .flowroot .fs th{ padding:4.5px 2px; line-height:1.34; }
.flowroot .fs{ margin-top:4px; }
.flowroot .fs-break .dec .standfirst{ margin-bottom:14px; }
.fs-break{ break-before:page; page-break-before:always; }
"""

CSS = FONTS_CSS + _apply(_CSS_TMPL, TOK) + PRINT
