# build3.py — execs the modules into dossier3.html. NO CSS here (it lives in design2.py).
import os, re
import design2, maps, prose, content, content2, content3

CSS = design2.CSS

def fig(key, num, caption):
    """Emit a computed figure inside the flow, right after the paragraph it argues."""
    svg = getattr(maps, key)()
    return (f'<figure class="map"><div class="fign" style="font-family:var(--mono);'
            f'font-size:8px;letter-spacing:.16em;margin-bottom:6px">FIG.&nbsp;{num}</div>'
            f'{svg}<figcaption>{caption}</figcaption></figure>')

def plate(slot, num, caption):
    """A photograph placeholder wired by slot letter. LANDSCAPE only. User supplies the file."""
    path = os.path.join("img", f"{slot}.jpg")
    letter = chr(64 + int(slot[1:]))
    if os.path.exists(path):
        src = path
    else:
        # a marked placeholder so the build never ships a blank; validate-images gates real files
        src = None
    inner = (f'<img src="{src}" alt="">' if src else
             f'<div style="height:2.35in;background:{design2.TOK["stone"]};border:1px solid '
             f'{design2.TOK["line"]};display:flex;align-items:center;justify-content:center;'
             f'font-family:var(--mono);font-size:9px;letter-spacing:.15em;color:{design2.TOK["muted"]}">'
             f'PLATE&nbsp;{letter}&nbsp;— {slot}.jpg</div>')
    return (f'<figure class="photo"><div class="fign" style="font-family:var(--mono);'
            f'font-size:8px;letter-spacing:.16em;margin-bottom:6px">PL.&nbsp;{letter}</div>'
            f'{inner}<figcaption>{caption}</figcaption></figure>')

# ---------- render a decision as a flow block ----------
def decision_block(d, fignum_ref, platenum_ref):
    parts = [f'<div class="dec opener">']
    parts.append(f'<div class="dnum"><span>Decision {d["n"]} · {d["cat"]}</span>'
                 f'<span class="rt">{d.get("rt","")}</span></div>')
    parts.append(f'<div class="dtitle">{d["title"]}</div>')
    parts.append(f'<div class="standfirst">{d["standfirst"]}</div>')
    parts.append(d["lede"])
    # figure inside the flow, after the lede, if this decision carries one
    if d.get("fig"):
        fignum_ref[0] += 1
        cap = FIG_CAPS.get(d["fig"], "")
        parts.append(fig(d["fig"], fignum_ref[0], cap))
    # the ledger
    parts.append(f'<div class="led-h"><span>The trade-off, scored</span>'
                 f'<span class="cols">{d["cols"]}</span></div>')
    parts.append('<table class="led">')
    for opt, num in d["rows"]:
        parts.append(f'<tr><td>{opt}</td><td class="num">{num}</td></tr>')
    parts.append('</table>')
    parts.append(f'<div style="font-family:var(--mono);font-size:7.5px;letter-spacing:.14em;'
                 f'color:var(--soft);margin:3px 0 0">{d["table_title"].upper()}</div>')
    # verdict
    parts.append(f'<div class="verdict">{d["verdict"]}</div>')
    # for / against
    parts.append('<ul class="forlist">')
    for f_ in d.get("for", []):
        parts.append(f'<li>{f_}</li>')
    for a_ in d.get("against", []):
        parts.append(f'<li>{a_}</li>')
    parts.append('</ul>')
    # a plate, if this decision's evidence is a counter habit
    if d.get("plate"):
        platenum_ref[0] += 1
        cap = PLATE_CAPS.get(d["plate"], "")
        parts.append(plate(d["plate"], platenum_ref[0], cap))
    # note
    if d.get("note"):
        parts.append(f'<div class="note">{d["note"]}</div>')
    parts.append('</div>')
    return "".join(parts)

# figure + plate captions (kept together so numbering is centralised)
FIG_CAPS = {
 "FIG_ASYMMETRY":"The same trip, two orders. Santorini last keeps the fast-boat leg away from your flight home; Santorini early, or a ferry on flight day, hands a summer wind a veto over your return. Drawn from real sea distances.",
 "FIG_CYCLADES":"The core Cyclades, drawn to scale from real sea distances from Piraeus. Santorini sits farthest south — the natural finale, and the leg the meltemi most likes to cancel. Dashed lines are the short inter-island hops.",
 "FIG_CRETE":"Crete end to end — roughly 160 miles. Chania to Heraklion alone is about a two-hour drive, which is why a western base and an eastern base are effectively two different trips, and why distance, not opening hours, is the limit.",
 "FIG_FERRYFLY":"Door-to-dock time by mode on the legs that matter. On the long legs a short flight buys back most of a day; on the short Cyclades hops the ferry is frequent, scenic, and barely slower.",
 "FIG_SEASON":"The year in bands: when the Cyclades are fully open, where the shoulder value sits, and where the meltemi and the crowds peak together in July and August — the one window when this book's sequencing risk is sharpest.",
 "FIG_ARRIVAL":"The arrival, drawn as an operation: airport to central Athens (~40 min by Metro Line 3) or on to Piraeus (~20–30 min more). The rule sits underneath — never book an island ferry for your arrival day.",
 "FIG_DECISIONTREE":"The island choice as a fork, not a ranking: one famous island as the finale, one value island as the trip's actual rest — Naxos for beaches and space, Paros for pace and connections.",
 "FIG_SHAPES":"The trip lengths as structures, sized by nights per stop. Each shape ends by flying back to Athens — the leg the wind can't cancel — and adds depth, not just islands, as the days grow.",
 "FIG_SEVERITY":"The twenty failure modes, ranked by consequence. Bar length is how much a single mistake in that tier can cost — from the whole trip down to an afternoon's comfort. Fix the top tier first.",
}
PLATE_CAPS = {
 "A01":"A Greek taverna table, set to share. The rule that outlives any restaurant list: eat a street back from the view, order to the middle of the table, tip 5–10% in cash. [Your photograph — landscape.]",
}

# ---------- assemble ----------
def build():
    fignum = [0]      # mutable counters threaded through the flow
    platenum = [0]

    # ---- the flow: everything except the cover, in reading order ----
    flow = []
    flow.append(f'<div class="dec">{prose.OPENING}{prose.HOWTO}{TOC}</div>')

    # THE GROUND — organising fact, with its scale figure right after the paragraph that argues it
    ground = prose.GROUND
    fignum[0] += 1
    ground_fig = fig("FIG_CYCLADES", fignum[0], FIG_CAPS["FIG_CYCLADES"])
    # insert the cyclades figure just before the closing pull-quote paragraph about Santorini
    ground = ground.replace('<div class="pull">',
                            ground_fig + '<div class="pull">', 1)
    flow.append(f'<div class="dec opener">{ground}</div>')

    flow.append(f'<div class="dec">{content2.BEFORE}</div>')
    # DAY ZERO with the arrival-transit diagram after the mechanics paragraph
    dayzero = content2.DAYZERO + prose.WONDER_ARRIVAL
    fignum[0] += 1
    arrival_fig = fig("FIG_ARRIVAL", fignum[0], FIG_CAPS["FIG_ARRIVAL"])
    dayzero = dayzero.replace('<p>Two arrival rules save',
                              arrival_fig + '<p>Two arrival rules save', 1)
    flow.append(f'<div class="dec opener">{dayzero}</div>')

    # TIMING with the season strip after the trap paragraph
    timing = content2.TIMING
    fignum[0] += 1
    season_fig = fig("FIG_SEASON", fignum[0], FIG_CAPS["FIG_SEASON"])
    timing = timing.replace('<p class="dropcap">', '<p class="dropcap">', 1)
    # place the figure after the second paragraph (the trap)
    timing = timing.replace('At the season\'s edges', season_fig + '<p>At the season\'s edges', 1)
    timing = timing.replace('<p>At the season\'s edges the calculus', 'At the season\'s edges the calculus', 1)
    flow.append(f'<div class="dec opener">{timing}</div>')

    flow.append(f'<div class="dec">{content2.SETPIECES}</div>')
    flow.append(f'<div class="dec opener">{content3.HOODS}</div>')
    flow.append(f'<div class="dec">{content2.EATING}</div>')

    # ---- THE DECISIONS ----
    flow.append('<div class="dec opener"><div class="eyebrow">The decisions — the heart</div>'
                '<h2 class="sec">Ten calls that decide a first trip</h2>'
                '<p class="dropcap">Each call below is a question you are already asking, answered with '
                'visible arithmetic and a verdict you can push back on. They are ordered so the trip '
                'assembles as you read — sequence first, because everything else is a corollary of it. '
                'We give the first one away free; it is the proof the rest are worth having.</p></div>')
    for d in content.DECISIONS:
        flow.append(decision_block(d, fignum, platenum))
        # money essay slots right after Decision 07 (money), reinforcing it
        if d["n"] == "07":
            flow.append(f'<div class="dec">{content2.MONEY}</div>')
        if d["n"] == "06":
            # ferry/fly figure already emitted in Decision 05/06? emit ferryfly under Decision 06's prose
            pass

    # ---- back chapters ----
    flow.append(f'<div class="dec opener">{content2.STAY}</div>')
    # THE PLAN with the trip-shapes figure after the intro
    plan = content2.PLAN
    fignum[0] += 1
    shapes_fig = fig("FIG_SHAPES", fignum[0], FIG_CAPS["FIG_SHAPES"])
    plan = plan.replace('<h3 class="sub">Five days', shapes_fig + '<h3 class="sub">Five days', 1)
    flow.append(f'<div class="dec opener">{plan}</div>')
    flow.append(f'<div class="dec opener">{content3.WHOFOR}</div>')
    flow.append(f'<div class="dec">{content2.DAYTRIPS}</div>')
    flow.append(f'<div class="dec opener">{content3.PRACTICAL}</div>')
    # FAILURE with the severity chart after the intro paragraph
    failure = content2.FAILURE
    fignum[0] += 1
    sev_fig = fig("FIG_SEVERITY", fignum[0], FIG_CAPS["FIG_SEVERITY"])
    failure = failure.replace('<h3 class="sub">Costs you the trip',
                              sev_fig + '<h3 class="sub">Costs you the trip', 1)
    flow.append(f'<div class="dec opener">{failure}</div>')
    flow.append(f'<div class="dec opener">{content2.WALLET}</div>')
    flow.append(f'<div class="dec opener">{content2.BACKMATTER}</div>')
    flow.append(f'<div class="dec">{content2.CLOSING}</div>')

    flow_html = ('<div class="flow flowroot">' +
                 "".join(flow) + '</div>')

    # ---- Field Sheet as its own flowed section ----
    fieldsheet_html = ('<div class="flow flowroot fs-break">'
                       f'<div class="dec opener">{content2.FIELDSHEET}</div></div>')

    # ---- cover ----
    cover_html = f'<div class="coverpage"><div class="cover">{maps.COVER()}</div></div>'

    html = (f'<!doctype html><html><head><meta charset="utf-8">'
            f'<style>{CSS}</style></head><body>'
            f'{cover_html}{flow_html}{fieldsheet_html}'
            f'</body></html>')

    with open("dossier3.html", "w") as f:
        f.write(html)
    # word count of body (rough)
    text = re.sub("<[^>]+>", " ", flow_html + fieldsheet_html)
    words = len(text.split())
    print(f"dossier3.html written · ~{words} body words · {fignum[0]} figures · {platenum[0]} plates")
    return words

# ---------- TOC (built after we know the chapter list) ----------
TOC = """
<div class="eyebrow">Contents</div>
<h2 class="sec">What's inside</h2>
<table class="toc">
<tr><td class="grp" colspan="2">The argument</td></tr>
<tr><td class="ti">The Ground — the trip is a sequence, and a wind governs it</td><td class="pg">7</td></tr>
<tr><td class="ti">Before You Fly — the checklist with deadlines</td><td class="pg">—</td></tr>
<tr><td class="ti">Day Zero — your first hours in Athens</td><td class="pg">—</td></tr>
<tr><td class="ti">Timing — when to go, and the seasonal trap</td><td class="pg">—</td></tr>
<tr><td class="ti">The Set Pieces — the Acropolis, the sunset, the port</td><td class="pg">—</td></tr>
<tr><td class="ti">Eating — the rule that outlives the list</td><td class="pg">—</td></tr>
<tr><td class="grp" colspan="2">The decisions</td></tr>
<tr><td class="ti">01 · Sequence — which islands, in what order <span class="gl">— the free call</span></td><td class="pg">9</td></tr>
<tr><td class="ti">02 · Fit — which islands actually suit you</td><td class="pg">—</td></tr>
<tr><td class="ti">03 · Base — where to sleep on each island</td><td class="pg">11</td></tr>
<tr><td class="ti">04 · Crete — one region or bust</td><td class="pg">13</td></tr>
<tr><td class="ti">05 · Ferry — fast boat or conventional</td><td class="pg">—</td></tr>
<tr><td class="ti">06 · Fly — when to fly the long legs</td><td class="pg">15</td></tr>
<tr><td class="ti">07 · Money — the card-reader question</td><td class="pg">24</td></tr>
<tr><td class="ti">08 · Value — Naxos or Paros</td><td class="pg">16</td></tr>
<tr><td class="ti">09 · Driving — car, and the permit Americans forget</td><td class="pg">—</td></tr>
<tr><td class="ti">10 · Athens — how long, opener or trip</td><td class="pg">—</td></tr>
<tr><td class="grp" colspan="2">The reference</td></tr>
<tr><td class="ti">Athens Up Close — the neighbourhoods</td><td class="pg">—</td></tr>
<tr><td class="ti">Who's Travelling — couples, families, budget &amp; splurge</td><td class="pg">—</td></tr>
<tr><td class="ti">The Practical Layer — connectivity, entry, safety</td><td class="pg">—</td></tr>
<tr><td class="ti">Where to Stay · The Plan · The Extra Day</td><td class="pg">—</td></tr>
<tr><td class="ti">Failure Modes — twenty ways it goes wrong, by consequence</td><td class="pg">—</td></tr>
<tr><td class="ti">The Wallet Card · What This Book Won't Tell You</td><td class="pg">31</td></tr>
<tr><td class="ti">The Field Sheet — the dated annex</td><td class="pg">—</td></tr>
</table>
"""

if __name__ == "__main__":
    build()
