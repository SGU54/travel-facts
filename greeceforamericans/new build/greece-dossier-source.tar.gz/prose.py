# prose.py — the OPENING and the essays. Register: Economist/Monocle, calm, no fluff.
# Every factual claim traces to the corpus and carries a provenance mark.
# Marks are helpers so the prose stays readable.

def mk(kind, label=None):
    sym = {"est": "●", "off": "◇", "sur": "▲", "vol": "◆"}[kind]
    txt = {"est": "ESTABLISHED", "off": "OFFICIAL", "sur": "SURVEYED", "vol": "VOLATILE"}[kind]
    if label:
        txt = label
    return f'<span class="mk {kind}">{sym}&nbsp;{txt}</span>'

EST = mk("est"); OFF = mk("off"); VOL = mk("vol")

# ---------------------------------------------------------------
# OPENING — the contract
# ---------------------------------------------------------------
OPENING = f"""
<div class="eyebrow">Opening — the contract</div>
<h1 class="t">You already have the facts.<span class="sub">What you don't have is the order they go in.</span></h1>
<div class="standfirst">This is not a guidebook. It is a decision manual — written so you can
disagree with us on any single call and still come out ahead of the trip you would have booked
without it.</div>

<p class="dropcap lead">Six weeks before a Greek island trip, the problem is never a shortage of
information. It is the opposite. You have forty browser tabs, a dozen contradictory itineraries,
and a rising suspicion that the choices interact in ways no single article explains. Which
island first. Fast boat or slow. Whether to fly. When to go. What a day actually costs. Each has
a clear answer somewhere online; what is almost nowhere is the one thing that decides a first
trip — how the answers <em>fit together</em>.</p>

<p>Here is the through-line of everything that follows. A first Greek trip is not chosen the way
the brochures imply — by picking the prettiest islands. It is chosen by <strong>sequence</strong>:
which islands, in what order, connected by which boat, ending where. Get the sequence right and
the trip is forgiving. Get it wrong — and specifically, put the wrong boat on the wrong day — and
a single cancelled ferry can cost you the flight home. That is the difference this book is built
to protect, and it is a difference the free web reliably fails to draw, because the facts that
make it live in different articles that never quite meet.</p>

<p>So we have done the meeting. We read the whole corpus, held it in mind at once, and drew the
connections no one page draws. What you are buying is not the facts — those are free, and we cite
where they came from on every line. What you are buying is the <em>synthesis</em>: the small number
of calls that actually shape the trip, each argued with visible arithmetic and a verdict you can
push back on. We would rather be argued with than believed. A manual that cannot be disagreed with
is just a list wearing a suit.</p>

<p>One more promise, stated plainly because the whole product rests on it: we do not fake certainty.
We will not name the restaurant we haven't eaten at, or print the room rate that is wrong by spring,
or pretend a per-day dollar figure means anything. Where a number moves, it lives on the dated Field
Sheet at the back, with the official source named, so you check it in your travel week rather than
trust our press date. What is in the Book ages slowly. What moves is quarantined. When the two
disagree, the Sheet wins.</p>
"""

# ---------------------------------------------------------------
# HOW TO READ — the marks + the two documents
# ---------------------------------------------------------------
HOWTO = f"""
<div class="eyebrow">How to read this</div>
<h2 class="sec">Four marks, two documents, one habit</h2>

<p>Every factual claim in this book carries a mark telling you how much weight it can bear and how
fast it ages. This is the product's spine, not decoration: it is how a paid manual earns trust that
a blog post cannot. Read the mark before you act on the claim.</p>

<table class="marks">
<tr><td class="m">{EST}</td><td>Structural. True for years — a geography, a distance, a rule of how the
network behaves. The core of the Book is built from these.</td></tr>
<tr><td class="m">{OFF}</td><td>A published rule or regulated figure — an entry requirement, a fare
class, a government advisory. Stable, but confirm against the official source before you rely on it.</td></tr>
<tr><td class="m">{mk("sur")}</td><td>Our own dated observation, marked with the month. A judgment we
stand behind, timestamped so you can weigh how fresh it is.</td></tr>
<tr><td class="m">{VOL}</td><td>A price, an hour, a schedule window. These <em>do not appear in the Book.</em>
They live on the Field Sheet, dated, because a live number printed in a book is a lie with a long shelf life.</td></tr>
</table>

<p style="margin-top:16px"><strong>The two documents.</strong> The <em>Book</em> — this — holds the
analysis that stays true across seasons: the sequence logic, the decisions, the failure modes, the
geography. It never carries a live price. The <em>Field Sheet</em> is the dated annex: the handful of
figures that move, each with the official place to re-check it. Carry the Book to decide; open the
Sheet in your travel week to confirm.</p>

<p><strong>The habit.</strong> When a decision cross-references another — "the arithmetic is in Money,
p.&nbsp;24" — follow it. The manual's value is in the network between the calls, not in any one page.
A first trip goes wrong at the seams; this book is mostly seams.</p>

<p><strong>A worked example.</strong> Suppose you read, in the Ferry chapter, that the meltemi "cancels
the fast catamarans first" carrying an {EST} mark. That tells you three things at once: it is structural,
so you can build a plan around it; it will still be true when you travel, so it is safe to treat as a
fixed constraint; and because it is not a {VOL} figure, you will not find it on the Field Sheet — it lives
in the Book because it does not move. Now suppose the same paragraph mentioned a fast-ferry fare. That
number would <em>not</em> appear here at all — it would be on the Sheet, dated, with the operator named,
because a price printed in a book is wrong within a season. Reading the mark first tells you whether to
act on a claim now or go confirm it in your travel week. Do that on every line and the book does its job.</p>

<div class="pull">Read the mark before you act on the claim. It is the difference between a fact you can
build on and one you must go re-check.</div>
"""

# ---------------------------------------------------------------
# THE GROUND — the organising fact
# ---------------------------------------------------------------
GROUND = f"""
<div class="eyebrow">The ground — the one fact that reorganises the trip</div>
<h2 class="sec">The trip is a sequence, and a wind governs it</h2>

<p class="dropcap">The single most important sentence in this book is one the free web scatters across
a dozen articles and almost never assembles: <strong>the order of your islands, and the boat you take
on the day you fly, decide whether a first Greek trip is smooth or ruined.</strong> Everything else —
which islands, how many, fast or slow, fly or ferry — is a corollary of getting that right.</p>

<p>Start with the physics, because the physics is not negotiable. In July and August a strong
northerly wind called the <em>meltemi</em> sweeps the Aegean. {EST} It does not merely make the
crossing bumpy. It cancels boats — and it cancels the <em>fast</em> boats first, because the
high-speed catamarans are lighter and cannot safely handle rough seas, while the big conventional
ferries keep sailing in conditions that ground the fast ones. {EST} This is the hinge on which a first
trip turns, and it is invisible on a sunny booking page in February.</p>

<p>Now layer the trip onto it. A first-timer's Greek trip is almost always Athens plus two Cyclades
islands over a week, or three over ten days. {EST} There are no direct flights from the islands to the
United States; you fly home from Athens, which means every island trip ends by getting back to Athens —
by ferry, or by a short domestic flight. {EST} That return is a fixed appointment. Miss it and you do
not lose an afternoon; you lose the trip's ending and pay to rebuild it.</p>

<p>Put the two together and the whole book falls out. If your last island hop is a fast catamaran,
scheduled tight against your flight home, you have handed a summer wind a veto over your return. The
fix is not exotic. It is <strong>sequence</strong>: end on an island with its own airport, so you can
fly back to Athens if the sea turns; {EST} never schedule the island-to-airport leg on your departure
day; {EST} and keep a buffer day before the international flight, so a cancelled boat costs you a spare
morning instead of the trip. {EST}</p>

<div class="pull">The facts are everywhere. The connection is almost nowhere. That gap is the
entire reason this book exists.</div>

<p>This is why Santorini — the island everyone puts at the centre of the dream — is a sequencing
problem, not a scenery problem. It sits at the far southern edge of the Cyclades: the furthest of the
common islands from Athens' port by sea, and the furthest from Mykonos. {EST} The figure opposite draws
it to scale from real distances. Being the farthest point, Santorini is the natural <em>finale</em> —
and the leg to it is exactly the fast-boat leg the wind most likes to cancel. So the call that governs
the trip is simple to state and easy to get wrong: <strong>sequence Santorini last, reach it with a
buffer, and never let the boat off it be the last thing between you and your flight.</strong> We give
that call away free, on the cover and here, because one real connection — shown, not asserted — is the
proof that the rest are worth buying.</p>
"""

# The two "wonder" paragraphs allowed (anticipation is part of the sale; three max across the book)
WONDER_ARRIVAL = """
<p>There is a particular hour worth planning for. You will land at Athens jet-lagged — Greece runs
seven hours ahead of the US East Coast, more from the West — and the instinct is to sightsee through
the fog. Resist it. The city will still be three thousand years old tomorrow. The trip that works
treats day one as a soft landing and saves the Acropolis for a rested morning, when the marble is
worth the climb rather than a blur you photographed to prove you were there.</p>
"""
