# content3.py — the second mining pass. Real corpus veins the first pass walked past:
# Athens neighbourhoods, the trip shaped by who's travelling, and the practical layer
# (connectivity, entry, safety). All corpus-sourced and marked.
from prose import mk
EST = mk("est"); OFF = mk("off"); VOL = mk("vol"); SUR = mk("sur")

# ---------------- ATHENS NEIGHBOURHOODS ----------------
HOODS = f"""
<div class="eyebrow">Athens up close — the neighbourhoods</div>
<h2 class="sec">Where to base, street by street</h2>

<p class="dropcap">Athens rewards a first-timer who understands its centre as a handful of distinct
neighbourhoods rather than one undifferentiated "old town." Where you base changes what your two or three
days feel like — the postcard, the market bustle, or the quiet local district a short walk from both. Each
sits within easy reach of the Acropolis and the metro that carries you to port and airport (Decision 10).</p>

<ul class="tick">
<li><b>Plaka — the historic old town.</b> The Athens of the postcards: neoclassical houses, bougainvillea-draped
lanes, and cafés spilling onto pedestrian streets, directly beneath the Acropolis. {EST} The most atmospheric
base and the most walkable to the ancient core; also the most visited, so it trades a little local life for
maximum charm and convenience.</li>
<li><b>Monastiraki — the market crossroads.</b> Bustling, central, and lively, with the flea market, quick
transport links, and a foot in both the ancient and the modern city. {EST} A practical, energetic base for a
first-timer who wants to be in the middle of everything.</li>
<li><b>Koukaki — the local-favourite district.</b> Just off the tourist track below the Acropolis, more
residential and relaxed, with neighbourhood tavernas and an easy walk to the sights. {EST} The choice for a
traveller who wants the centre's access without the centre's crowds.</li>
</ul>

<p>The through-line is the same as the island bases (Decision 03): pick the area for what it puts within reach
and who it suits, then let the room follow. For a first trip, all three keep you walking distance from the
Acropolis and a short metro ride from Piraeus — which is the practical test that matters, since Athens is both
the opener and the hinge of the whole trip. {EST}</p>
"""

# ---------------- WHO THE TRIP IS FOR ----------------
WHOFOR = f"""
<div class="eyebrow">Who's travelling — the trip, shaped</div>
<h2 class="sec">The same Greece, tuned to the party</h2>

<p class="dropcap">The decisions in this book hold for any first trip, but three kinds of traveller should tune
them, because the same corpus produces meaningfully different trips depending on who is going. The tuning is
mostly about which islands and what pace — the sequencing logic underneath does not change.</p>

<h3 class="sub">Couples and honeymooners</h3>
<p>Greece is one of the world's great romantic destinations, and the question for couples is which islands
deliver the most magic — some are built for romance with sunset views and intimate villages, others are
livelier. {EST} The honeymoon shape that works mirrors the general one but slows it down: Athens (2–3 nights) →
Naxos or Paros (3 nights, to slow down together) → Santorini (3–4 nights, the finale) → fly back to Athens.
{EST} About 8–10 days lets a couple combine Athens with two islands at a relaxed pace. {EST} The move that
protects the romance is the same one that protects everyone: end high, with a buffer, and don't spend the
trip on boats.</p>

<h3 class="sub">Families with children</h3>
<p>Greece is one of the easier European trips to do with kids: the food is simple and crowd-pleasing, the
beaches are warm and shallow, Greeks genuinely welcome children, and the ancient sites turn history into
something a child can stand inside. {EST} The trick for a first family trip is choosing the right islands and
pacing the ferries so you are not dragging tired children across the Aegean — which is the sequencing chapter
stated in a family key. {EST} Value islands with big, gentle beaches (Naxos especially) suit a family better
than the crowded, pricey headline pair. {EST}</p>

<h3 class="sub">Budget and splurge</h3>
<p>The trip's cost is set by its shape, not the traveller's discipline (Money, Decision 07). A budget trip
leans on the value levers — shoulder season, value islands, guesthouses, deck-class ferries, taverna meals —
and sits comfortably at the low end of the range, well below the Santorini-and-Mykonos version. {EST} A splurge
means caldera suites and private transfers, and on Santorini in particular a luxury traveller should arrange
private transfers for every port and airport, because the island's climb from the port is no place to be
stranded with bags. {EST} The levers are the same for everyone; which ones you pull is the whole of the budget.</p>
"""

# ---------------- CONNECTIVITY / ENTRY / SAFETY (the practical layer) ----------------
PRACTICAL = f"""
<div class="eyebrow">The practical layer — connectivity, entry, safety</div>
<h2 class="sec">The small things that are easy at home and hard on arrival</h2>

<p class="dropcap">A first trip runs smoother when a few practical matters are settled before departure rather
than improvised on the ground. None is a decision in the sense the earlier chapters are — there is a clear right
answer — but each is easy to get wrong by default.</p>

<h3 class="sub">Staying connected</h3>
<p>The simplest approach for an American is an eSIM arranged before you land, so you arrive already connected
rather than hunting for airport Wi-Fi or a local SIM. {EST} Data makes the ferry-schedule checks this book keeps
recommending trivial — you can confirm a sailing or a port from the taverna table. Set it up at home; it is a
ten-minute task there and an annoyance on arrival.</p>

<h3 class="sub">Entry and documents</h3>
<p>US citizens can visit Greece visa-free for tourism for up to 90 days within any 180-day period, as part of
the Schengen Area. {OFF} A new pre-travel authorisation, ETIAS, is being introduced for visa-exempt visitors;
confirm its current status for your travel dates and apply if required, well ahead of departure. Both the entry
rule and the ETIAS status belong on the Field Sheet, checked against the official source, because the details
of a new system move. {VOL}</p>

<h3 class="sub">Safety and etiquette</h3>
<p>Greece is, on the whole, a safe and welcoming destination for American travellers, and the etiquette that
matters is small and easy: modest tipping (Decision 07), a relaxed pace at meals (Eating), and the ordinary
traveller's caution in crowded tourist areas. {EST} The customs that make a difference are ones of pace and
courtesy rather than rules — Greeks welcome visitors, and a first trip that adopts the local rhythm rather than
importing an American one is the one that goes well. {EST}</p>
"""
